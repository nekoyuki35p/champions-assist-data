from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "app/src/main/java"
errors = []

def read(path):
    return path.read_text(encoding="utf-8")

def check(value, message):
    if not value:
        errors.append(message)

app_gradle = read(ROOT / "app/build.gradle.kts")
service = read(SRC / "jp/nekoyuki/championsassist/live/MediaProjectionAssistService.kt")
overlay = read(SRC / "jp/nekoyuki/championsassist/live/OverlayController.kt")
tracker = read(SRC / "jp/nekoyuki/championsassist/live/FrameTracker.kt")
store = read(SRC / "jp/nekoyuki/championsassist/live/TrackedLabelStore.kt")

check('versionName = "0.8.6"' in app_gradle, "versionName 0.8.6 missing")
check('org.jetbrains.kotlin.android' not in app_gradle, "legacy Kotlin Android plugin remains")
check('kotlinOptions' not in app_gradle, "legacy kotlinOptions remains")

for name in [
    "TrackingModels.kt",
    "FrameTracker.kt",
    "ScrollStateDetector.kt",
    "TrackedLabelStore.kt",
]:
    check(
        (SRC / "jp/nekoyuki/championsassist/live" / name).is_file(),
        f"{name} missing"
    )

check("FrameTracker()" in service, "FrameTracker not wired")
check("TrackedLabelStore()" in service, "TrackedLabelStore not wired")
check("ScrollStateDetector()" in service, "ScrollStateDetector not wired")
check("TRACKING_INTERVAL_MS" in service, "tracking interval missing")
check("forceOcrRequested" in service, "OCR force flag missing")
check("showTrackedLabels" in overlay, "tracked overlay API missing")
check("estimateMotion" in tracker, "motion estimator missing")
check("reconcile" in store, "OCR reconcile missing")
check(".showMatches(" not in service, "old showMatches API remains in service")
check("scanJob" not in service, "old scanJob remains")

for p in SRC.rglob("*.kt"):
    s = read(p)
    check(s.count("{") == s.count("}"), f"{p.name}: brace mismatch")
    check(s.count("(") == s.count(")"), f"{p.name}: parenthesis mismatch")

for p in [
    ROOT / "app/src/main/assets/champions_meeting.json",
    ROOT / "app/src/main/assets/remote_config.json",
    ROOT / "hosting/latest.json",
]:
    try:
        json.loads(read(p))
    except Exception as exc:
        errors.append(f"{p.name}: invalid JSON: {exc}")

if errors:
    print("PRE-FLIGHT FAILED")
    for error in errors:
        print("ERROR:", error)
    sys.exit(1)

print("PRE-FLIGHT OK")
print("- v0.8.6 version")
print("- hybrid tracker wiring")
print("- tracked overlay API")
print("- OCR reconcile / purge")
print("- Kotlin structural checks")
print("- JSON validation")
