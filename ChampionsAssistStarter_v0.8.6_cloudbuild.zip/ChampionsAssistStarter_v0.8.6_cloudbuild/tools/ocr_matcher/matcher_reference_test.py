import re
import unicodedata


def normalize(value: str) -> str:
    text = unicodedata.normalize("NFKC", value)
    text = (
        text.replace("◯", "○")
        .replace("〇", "○")
        .replace("●", "○")
        .lower()
    )
    return re.sub(
        r"""[\s　・･:：,，.。!！?？"'“”‘’`\[\]【】{}｛｝<>＜＞「」『』]""",
        "",
        text,
    )


def levenshtein(left: str, right: str) -> int:
    if left == right:
        return 0
    if not left:
        return len(right)
    if not right:
        return len(left)

    previous = list(range(len(right) + 1))
    for i, lc in enumerate(left):
        current = [i + 1]
        for j, rc in enumerate(right):
            current.append(
                min(
                    current[j] + 1,
                    previous[j + 1] + 1,
                    previous[j] + (0 if lc == rc else 1),
                )
            )
        previous = current
    return previous[-1]


def score(alias: str, candidate: str) -> float:
    alias = normalize(alias)
    candidate = normalize(candidate)

    if not alias or not candidate:
        return 0.0
    if alias == candidate:
        return 1.0

    if len(alias) >= 2 and candidate.startswith(alias):
        suffix = candidate[len(alias):]
        if suffix and re.fullmatch(r"[0-9pt]+", suffix):
            return 0.98

    if len(alias) >= 3 and alias in candidate:
        return 0.98

    if (
        len(candidate) >= 3
        and candidate in alias
        and len(candidate) / len(alias) >= 0.78
    ):
        return 0.90

    if len(alias) < 4 or len(candidate) < 4:
        return 0.0

    max_len = max(len(alias), len(candidate))
    if max_len > max(len(alias) * 2, len(alias) + 8):
        return 0.0

    return 1.0 - levenshtein(alias, candidate) / max_len


cases = [
    ("王手", "王手 180", 0.98),
    ("王手", "王手 180Pt", 0.98),
    ("差しコーナー○", "差し コーナー ◯", 1.0),
    ("中距離直線◎", "中距離直線◎ 160Pt", 0.98),
    ("ネバーギブアップ", "ネバーギプアップ", 0.80),
]

for alias, ocr, minimum in cases:
    actual = score(alias, ocr)
    assert actual >= minimum, (alias, ocr, actual)

print("OCR matcher reference tests passed.")
