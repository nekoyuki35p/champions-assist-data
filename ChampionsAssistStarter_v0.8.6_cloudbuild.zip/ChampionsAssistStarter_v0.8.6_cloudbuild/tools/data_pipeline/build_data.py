from __future__ import annotations

import argparse
import hashlib
import json
import re
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

import requests
from bs4 import BeautifulSoup, Tag


STYLE_LABELS = {
    "nige": "逃げ",
    "senko": "先行",
    "sashi": "差し",
    "oikomi": "追込",
}

STAT_LABELS = {
    "スピード": "speed",
    "スタミナ": "stamina",
    "パワー": "power",
    "根性": "guts",
    "賢さ": "wisdom",
}

GRADE_PRIORITY = {
    "S": 100,
    "A": 70,
    "B": 40,
    "C": 20,
}

USER_AGENT = (
    "ChampionsAssistDataUpdater/0.4 "
    "(personal-use prototype; respectful low-frequency fetch)"
)


def normalize_text(value: str) -> str:
    value = value.replace("\u3000", " ").replace("\xa0", " ")
    value = value.replace("◯", "○")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def first_int(value: str) -> int | None:
    match = re.search(r"\d+", value.replace(",", ""))
    return int(match.group(0)) if match else None


def stable_skill_id(name: str) -> str:
    digest = hashlib.sha1(normalize_text(name).encode("utf-8")).hexdigest()[:12]
    return f"skill_{digest}"


def build_aliases(raw: str) -> list[str]:
    text = normalize_text(raw)
    aliases: list[str] = []

    def add(value: str) -> None:
        value = normalize_text(value)
        if value and value not in aliases:
            aliases.append(value)

    add(text)

    cleaned = re.sub(r"〖[^〗]+〗", "", text)
    cleaned = cleaned.replace("（超重要）", "").replace("(超重要)", "")
    cleaned = normalize_text(cleaned)
    add(cleaned)

    # 「マイル直線◎/○」のような表記は、OCRがどちらを読んでも一致できるよう展開。
    circle_match = re.search(r"(.+?)(◎|○)\s*/\s*(◎|○)$", cleaned)
    if circle_match:
        base = circle_match.group(1)
        add(f"{base}{circle_match.group(2)}")
        add(f"{base}{circle_match.group(3)}")

    # 「英俊豪傑（比類なき）」のような金/白スキル併記もaliasesへ。
    for inner in re.findall(r"[（(]([^()（）]+)[）)]", cleaned):
        inner = normalize_text(inner)
        if (
            inner
            and not re.search(r"\d", inner)
            and "進化枠" not in inner
            and len(inner) <= 30
        ):
            add(inner)

    return aliases


def find_heading_containing(soup: BeautifulSoup, needle: str) -> Tag | None:
    for level in ("h2", "h3", "h4"):
        for heading in soup.find_all(level):
            if needle in normalize_text(heading.get_text(" ", strip=True)):
                return heading
    return None


def find_next_table(node: Tag | None) -> Tag | None:
    if node is None:
        return None
    return node.find_next("table")


def parse_target_stats(soup: BeautifulSoup) -> dict:
    heading = find_heading_containing(soup, "目標ステータス")
    table = find_next_table(heading)
    if table is None:
        return {}

    rows = table.find_all("tr")
    if len(rows) < 2:
        return {}

    headers = [
        normalize_text(cell.get_text(" ", strip=True))
        for cell in rows[0].find_all(["th", "td"])
    ]
    values = [
        normalize_text(cell.get_text(" ", strip=True))
        for cell in rows[1].find_all(["th", "td"])
    ]

    result = {}
    for header, display in zip(headers, values):
        key = STAT_LABELS.get(header)
        if not key:
            continue
        result[key] = {
            "value": first_int(display),
            "operator": ">=" if ("↑" in display or "以上" in display) else None,
            "display": display or "―",
        }

    return result


def tag_text_contains(tag: Tag, needle: str) -> bool:
    return needle in normalize_text(tag.get_text(" ", strip=True))


def find_style_skill_table(
    soup: BeautifulSoup,
    style: str,
    source_styles: list[str],
) -> Tag | None:
    style_label = STYLE_LABELS[style]

    # 複数脚質記事では「■差しの優先スキル一覧」「■追込の優先スキル一覧」
    # の直後の表を優先。
    if len(source_styles) > 1:
        needle = f"{style_label}の優先スキル一覧"
        for tag in soup.find_all(["p", "div", "strong", "b", "h3", "h4"]):
            if tag_text_contains(tag, needle):
                table = tag.find_next("table")
                if table is not None:
                    return table

    # 単独脚質記事、またはマーカーが見つからない場合。
    heading = find_heading_containing(soup, "優先スキル一覧")
    if heading is None:
        return None

    if len(source_styles) == 1:
        return heading.find_next("table")

    # 複数脚質でもHTML構造が変わった場合、優先スキル見出し以降の
    # スタイル名を含む要素を探す。
    cursor = heading
    while cursor:
        cursor = cursor.find_next()
        if cursor is None:
            break
        if isinstance(cursor, Tag):
            text = normalize_text(cursor.get_text(" ", strip=True))
            if f"{style_label}の優先スキル一覧" in text:
                return cursor.find_next("table")

    return None


def parse_skill_table(table: Tag | None, source_id: str) -> list[dict]:
    if table is None:
        return []

    rows = table.find_all("tr")
    if len(rows) < 2:
        return []

    header_cells = rows[0].find_all(["th", "td"])
    grades: list[str | None] = []
    for cell in header_cells:
        text = normalize_text(cell.get_text(" ", strip=True)).upper()
        match = re.search(r"(?:優先度)?\s*([SABC])", text)
        grades.append(match.group(1) if match else None)

    skills: list[dict] = []
    seen: set[tuple[str, str]] = set()

    for row in rows[1:]:
        cells = row.find_all(["th", "td"])
        for index, cell in enumerate(cells):
            if index >= len(grades):
                continue
            grade = grades[index]
            if grade is None:
                continue

            raw = normalize_text(cell.get_text(" ", strip=True))
            if not raw or raw in {"-", "―"}:
                continue

            aliases = build_aliases(raw)
            if not aliases:
                continue

            display_name = aliases[0]
            key = (display_name, grade)
            if key in seen:
                continue
            seen.add(key)

            skills.append(
                {
                    "id": stable_skill_id(display_name),
                    "name": display_name,
                    "aliases": aliases,
                    # 記事の優先表だけではスキル種別を断定しない。
                    "category": "other",
                    "grade": grade,
                    # 「Sだから加速として有効」などの推測はしない。
                    "effectiveness": None,
                    "priority": GRADE_PRIORITY.get(grade, 0),
                    "isRecommended": True,
                    "reason": None,
                    "conditions": [],
                    "sourceIds": [source_id],
                }
            )

    return skills


def parse_published_at(soup: BeautifulSoup) -> str | None:
    meta = soup.find("meta", attrs={"property": "article:published_time"})
    if meta and meta.get("content"):
        return str(meta["content"])

    time_tag = soup.find("time")
    if time_tag:
        if time_tag.get("datetime"):
            return str(time_tag["datetime"])
        text = normalize_text(time_tag.get_text(" ", strip=True))
        match = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日", text)
        if match:
            y, m, d = map(int, match.groups())
            return f"{y:04d}-{m:02d}-{d:02d}"

    return None


def parse_title(soup: BeautifulSoup) -> str:
    h1 = soup.find("h1")
    if h1:
        return normalize_text(h1.get_text(" ", strip=True))
    if soup.title:
        return normalize_text(soup.title.get_text(" ", strip=True))
    return "タイトル取得失敗"


def fetch_html(url: str, timeout: int = 20) -> str:
    response = requests.get(
        url,
        headers={"User-Agent": USER_AGENT},
        timeout=timeout,
    )
    response.raise_for_status()
    response.encoding = response.apparent_encoding or response.encoding
    return response.text


@dataclass
class ParsedSource:
    source_entry: dict
    stats: dict
    skills_by_style: dict[str, list[dict]]


def parse_source_from_html(
    *,
    html: str,
    url: str,
    source_id: str,
    styles: list[str],
    article_type: str = "style_guide",
) -> ParsedSource:
    soup = BeautifulSoup(html, "html.parser")
    stats = parse_target_stats(soup)

    skills_by_style = {
        style: parse_skill_table(
            find_style_skill_table(soup, style, styles),
            source_id,
        )
        for style in styles
    }

    checked_at = datetime.now(timezone.utc).isoformat()

    source_entry = {
        "id": source_id,
        "siteName": "ウマ娘ラボ",
        "title": parse_title(soup),
        "url": url,
        "articleType": article_type,
        "runningStyle": styles[0] if len(styles) == 1 else None,
        "publishedAt": parse_published_at(soup),
        "checkedAt": checked_at,
    }

    return ParsedSource(
        source_entry=source_entry,
        stats=stats,
        skills_by_style=skills_by_style,
    )


def blank_target_stats() -> dict:
    return {
        key: {"value": None, "operator": None, "display": "―"}
        for key in ("speed", "stamina", "power", "guts", "wisdom")
    }


def merge_target_stats(stats: dict) -> dict:
    base = blank_target_stats()
    base.update(stats)
    return base


def build_output(config: dict, parsed_sources: list[ParsedSource]) -> dict:
    styles = {
        key: {
            "displayName": label,
            "contentStatus": "waiting_article",
            "targetStats": blank_target_stats(),
            "recommendedAptitudes": [],
            "skills": [],
            "notes": [],
            "sourceIds": [],
            "updatedAt": None,
        }
        for key, label in STYLE_LABELS.items()
    }

    source_entries = []

    for parsed, source_cfg in zip(parsed_sources, config["sources"]):
        source_entries.append(parsed.source_entry)
        now = parsed.source_entry["checkedAt"]

        for style in source_cfg["styles"]:
            style_data = styles[style]
            if parsed.stats:
                style_data["targetStats"] = merge_target_stats(parsed.stats)

            skills = parsed.skills_by_style.get(style, [])
            if skills:
                style_data["skills"] = skills

            style_data["sourceIds"].append(source_cfg["id"])
            style_data["updatedAt"] = now

            has_stats = any(
                item.get("value") is not None
                for item in style_data["targetStats"].values()
            )
            has_skills = bool(style_data["skills"])

            if has_stats and has_skills:
                style_data["contentStatus"] = "ready"
            elif has_stats or has_skills:
                style_data["contentStatus"] = "partial"

    available = [
        key
        for key, value in styles.items()
        if value["contentStatus"] in {"ready", "partial"}
    ]
    waiting = [
        key
        for key, value in styles.items()
        if value["contentStatus"] == "waiting_article"
    ]

    generated_at = datetime.now(timezone.utc).isoformat()

    return {
        "schemaVersion": config.get("schemaVersion", "0.1.0"),
        "dataVersion": config.get(
            "dataVersion",
            datetime.now().strftime("%Y.%m.%d.%H%M"),
        ),
        "meeting": config["meeting"],
        "course": config["course"],
        "runningStyles": styles,
        "sources": source_entries,
        "metadata": {
            "generatedAt": generated_at,
            "generator": "champions-assist-data-pipeline-v0.4",
            "sourceSite": "ウマ娘ラボ",
            "isComplete": len(waiting) == 0,
            "isSample": False,
            "availableStyles": available,
            "waitingStyles": waiting,
        },
    }


def validate_output(data: dict) -> list[str]:
    errors: list[str] = []

    for style_key, style in data["runningStyles"].items():
        status = style["contentStatus"]
        skills = style["skills"]

        if status == "ready" and not skills:
            errors.append(
                f"{style_key}: readyなのにskillsが空です"
            )

        for skill in skills:
            if skill["grade"] not in {"S", "A", "B", "C"}:
                errors.append(
                    f'{style_key}: 未対応grade {skill["grade"]}'
                )
            if not skill["name"]:
                errors.append(f"{style_key}: skill.nameが空です")

    return errors


def run(config_path: Path, output_path: Path | None = None) -> Path:
    config = json.loads(config_path.read_text(encoding="utf-8"))

    parsed_sources: list[ParsedSource] = []

    for index, source in enumerate(config["sources"]):
        print(f'[fetch] {source["url"]}')
        html = fetch_html(source["url"])
        parsed_sources.append(
            parse_source_from_html(
                html=html,
                url=source["url"],
                source_id=source["id"],
                styles=source["styles"],
                article_type=source.get("articleType", "style_guide"),
            )
        )

        # サイトへ連続アクセスしすぎない。
        if index < len(config["sources"]) - 1:
            time.sleep(float(config.get("requestDelaySeconds", 2.0)))

    output = build_output(config, parsed_sources)
    errors = validate_output(output)
    if errors:
        raise RuntimeError(
            "生成JSON検証エラー:\n- " + "\n- ".join(errors)
        )

    if output_path is None:
        output_path = (
            config_path.parent
            / config.get(
                "outputPath",
                "../../app/src/main/assets/champions_meeting.json",
            )
        ).resolve()

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(output, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"[ok] {output_path}")
    for key, value in output["runningStyles"].items():
        print(
            f'  {STYLE_LABELS[key]}: '
            f'{value["contentStatus"]}, '
            f'{len(value["skills"])} skills'
        )

    return output_path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        default="config.current.json",
        help="設定JSON",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="出力先を上書き",
    )
    args = parser.parse_args()

    config_path = Path(args.config).resolve()
    output_path = Path(args.output).resolve() if args.output else None
    run(config_path, output_path)


if __name__ == "__main__":
    main()
