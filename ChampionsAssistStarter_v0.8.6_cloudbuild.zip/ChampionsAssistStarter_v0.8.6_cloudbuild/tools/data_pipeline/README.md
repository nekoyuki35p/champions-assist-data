# Data Pipeline v0.4

ウマ娘ラボの脚質別育成論から、Champions Assistが読む
`champions_meeting.json` を生成するための更新ツールです。

## 取得するもの

- 目標ステータス5種
- 優先スキル表 S / A / B
- 記事タイトル
- 記事URL
- 公開日時（取得できる場合）
- チェック日時

## 取得しない / 推測しないもの

- S/A/B表だけでは分からない「加速 / 速度」カテゴリ
- 有効理由
- 発動条件
- スキル効果量

これらを推測で埋めると攻略情報が変質するため、
v0.4では `category: other`, `effectiveness: null`, `reason: null`
として保持します。

## 実行

```bash
cd tools/data_pipeline
python -m pip install -r requirements.txt
python test_parser.py
python build_data.py --config config.current.json
```

成功するとアプリ側の

`app/src/main/assets/champions_meeting.json`

が更新されます。

## 次回チャンミ

`config.current.json` の

- meeting
- course
- sources[].url
- sources[].styles

を更新します。

将来はこの設定更新自体も自動化します。

## アクセス方針

- 起動時にサイトへ直接アクセスするAndroid設計にはしない
- 更新処理は低頻度のデータ生成ジョブとして分離
- 複数記事取得の間に待機時間を入れる
- 元記事URLをJSONへ保持する
- サイト構造変更時は自動生成を失敗させ、誤データを配信しない
