from pathlib import Path

from build_data import parse_source_from_html


BASE = Path(__file__).resolve().parent


def test_single():
    html = (BASE / "fixture_single.html").read_text(encoding="utf-8")
    parsed = parse_source_from_html(
        html=html,
        url="https://example.invalid/senko",
        source_id="test_senko",
        styles=["senko"],
    )

    assert parsed.stats["speed"]["value"] == 2150
    assert parsed.stats["stamina"]["display"] == "1800↑+白回復1個"

    skills = parsed.skills_by_style["senko"]
    assert len(skills) == 5
    assert skills[0]["grade"] == "S"

    line_skill = next(s for s in skills if "中距離直線" in s["name"])
    assert "中距離直線◎" in line_skill["aliases"]
    assert "中距離直線○" in line_skill["aliases"]

    gold = next(s for s in skills if "金スキル" in s["name"])
    assert "白スキル" in gold["aliases"]


def test_multi():
    html = (BASE / "fixture_multi.html").read_text(encoding="utf-8")
    parsed = parse_source_from_html(
        html=html,
        url="https://example.invalid/back",
        source_id="test_back",
        styles=["sashi", "oikomi"],
    )

    assert parsed.stats["speed"]["value"] == 2100
    assert any(
        "差し直線" in skill["name"]
        for skill in parsed.skills_by_style["sashi"]
    )
    assert any(
        "追込直線" in skill["name"]
        for skill in parsed.skills_by_style["oikomi"]
    )


if __name__ == "__main__":
    test_single()
    test_multi()
    print("All parser tests passed.")
