package jp.nekoyuki.championsassist.ui.assist

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ImageSearch
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import jp.nekoyuki.championsassist.data.model.ChampionsMeetingData
import jp.nekoyuki.championsassist.live.LiveAssistStatus
import jp.nekoyuki.championsassist.live.MediaProjectionAssistService
import jp.nekoyuki.championsassist.ocr.JapaneseOcrRecognizer
import jp.nekoyuki.championsassist.ocr.SkillAliasMatcher
import jp.nekoyuki.championsassist.ocr.SkillOcrMatch
import jp.nekoyuki.championsassist.settings.AssistSettingsStore
import jp.nekoyuki.championsassist.ui.AppDestination
import jp.nekoyuki.championsassist.ui.home.RunningStyle
import jp.nekoyuki.championsassist.ui.skills.categoryLabel
import kotlinx.coroutines.launch

private enum class OcrUiStatus {
    IDLE,
    READING,
    SUCCESS,
    NO_MATCH,
    ERROR
}

@OptIn(
    ExperimentalMaterial3Api::class
)
@Composable
fun AssistScreen(
    meetingData:
        ChampionsMeetingData,
    selectedStyle:
        RunningStyle,
    onStyleSelected:
        (RunningStyle) -> Unit,
    onBack:
        () -> Unit,
    onNavigate:
        (AppDestination) -> Unit
) {
    val context =
        LocalContext.current

    val appContext =
        context.applicationContext

    val scope =
        rememberCoroutineScope()

    val recognizer =
        remember {
            JapaneseOcrRecognizer(
                appContext
            )
        }

    DisposableEffect(
        recognizer
    ) {
        onDispose {
            recognizer.close()
        }
    }

    val matcher =
        remember {
            SkillAliasMatcher()
        }

    val settingsStore =
        remember {
            AssistSettingsStore(
                appContext
            )
        }

    val liveState by
        MediaProjectionAssistService
            .state
            .collectAsState()

    var selectedImageUriText
        by rememberSaveable {
            mutableStateOf<String?>(
                null
            )
        }

    var ocrStatusName
        by rememberSaveable {
            mutableStateOf(
                OcrUiStatus
                    .IDLE
                    .name
            )
        }

    var statusMessage
        by rememberSaveable {
            mutableStateOf(
                "スクリーンショットOCRも利用できます。"
            )
        }

    var rawOcrText
        by rememberSaveable {
            mutableStateOf("")
        }

    var ocrLineCount
        by rememberSaveable {
            mutableStateOf(0)
        }

    var matches
        by remember {
            mutableStateOf(
                emptyList<
                    SkillOcrMatch
                >()
            )
        }

    val ocrStatus =
        runCatching {
            OcrUiStatus
                .valueOf(
                    ocrStatusName
                )
        }.getOrDefault(
            OcrUiStatus.IDLE
        )

    val currentStyleData =
        meetingData
            .runningStyles[
                selectedStyle.key
            ]

    fun analyzeUri(
        uri: Uri
    ) {
        selectedImageUriText =
            uri.toString()

        ocrStatusName =
            OcrUiStatus
                .READING
                .name

        statusMessage =
            "日本語OCRでスキル名を読み取っています…"

        rawOcrText = ""
        ocrLineCount = 0
        matches = emptyList()

        scope.launch {
            runCatching {
                recognizer
                    .recognize(uri)
            }.onSuccess { result ->
                rawOcrText =
                    result.rawText

                ocrLineCount =
                    result.lines.size

                val settings =
                    settingsStore
                        .load()

                val matched =
                    matcher.match(
                        recognizedLines =
                            result.lines,
                        skills =
                            currentStyleData
                                ?.skills
                                .orEmpty(),
                        minConfidence =
                            settings
                                .minConfidence
                    )
                        .filter {
                            settings
                                .shouldShowGrade(
                                    it.grade
                                )
                        }

                matches =
                    matched

                if (
                    matched.isEmpty()
                ) {
                    ocrStatusName =
                        OcrUiStatus
                            .NO_MATCH
                            .name

                    statusMessage =
                        "文字は読めましたが、登録済みaliasesへの一致はありませんでした。"
                } else {
                    ocrStatusName =
                        OcrUiStatus
                            .SUCCESS
                            .name

                    statusMessage =
                        "${matched.size}件を認識しました。"
                }
            }.onFailure { error ->
                ocrStatusName =
                    OcrUiStatus
                        .ERROR
                        .name

                statusMessage =
                    "OCRに失敗しました: ${error.message ?: "不明なエラー"}"
            }
        }
    }


    val picker =
        rememberLauncherForActivityResult(
            contract =
                ActivityResultContracts
                    .PickVisualMedia()
        ) { uri ->
            if (
                uri != null
            ) {
                analyzeUri(uri)
            }
        }

    val mediaProjectionLauncher =
        rememberLauncherForActivityResult(
            contract =
                ActivityResultContracts
                    .StartActivityForResult()
        ) { result ->
            val data =
                result.data

            if (
                result.resultCode ==
                Activity.RESULT_OK &&
                data != null
            ) {
                val serviceIntent =
                    MediaProjectionAssistService
                        .startIntent(
                            context =
                                appContext,
                            resultCode =
                                result
                                    .resultCode,
                            data =
                                data,
                            styleKey =
                                selectedStyle
                                    .key
                        )

                ContextCompat
                    .startForegroundService(
                        appContext,
                        serviceIntent
                    )
            }
        }

    val overlayPermissionLauncher =
        rememberLauncherForActivityResult(
            contract =
                ActivityResultContracts
                    .StartActivityForResult()
        ) {
            if (
                Settings
                    .canDrawOverlays(
                        context
                    )
            ) {
                val manager =
                    context
                        .getSystemService(
                            Context.MEDIA_PROJECTION_SERVICE
                        ) as MediaProjectionManager

                mediaProjectionLauncher
                    .launch(
                        manager
                            .createScreenCaptureIntent()
                    )
            }
        }

    fun startProjectionRequest() {
        if (
            !Settings
                .canDrawOverlays(
                    context
                )
        ) {
            overlayPermissionLauncher
                .launch(
                    Intent(
                        Settings
                            .ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse(
                            "package:${context.packageName}"
                        )
                    )
                )

            return
        }

        val projectionManager =
            context
                .getSystemService(
                    Context.MEDIA_PROJECTION_SERVICE
                ) as MediaProjectionManager

        mediaProjectionLauncher
            .launch(
                projectionManager
                    .createScreenCaptureIntent()
            )
    }


    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text =
                                "スキルアシスト",
                            fontWeight =
                                FontWeight.Bold
                        )

                        Text(
                            text =
                                "${meetingData.meeting.title} / ${selectedStyle.label}",
                            style =
                                MaterialTheme
                                    .typography
                                    .labelSmall,
                            color =
                                MaterialTheme
                                    .colorScheme
                                    .onSurfaceVariant,
                            maxLines = 1,
                            overflow =
                                TextOverflow
                                    .Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick =
                            onBack
                    ) {
                        Icon(
                            imageVector =
                                Icons.Default
                                    .ArrowBack,
                            contentDescription =
                                "戻る"
                        )
                    }
                }
            )
        },
        bottomBar = {
            AssistBottomNavigation(
                onNavigate =
                    onNavigate
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(
                        innerPadding
                    ),
            contentPadding =
                PaddingValues(
                    start =
                        16.dp,
                    end =
                        16.dp,
                    top =
                        12.dp,
                    bottom =
                        28.dp
                ),
            verticalArrangement =
                Arrangement
                    .spacedBy(
                        14.dp
                    )
        ) {
            item {
                StyleSelector(
                    selectedStyle =
                        selectedStyle,
                    onStyleSelected = {
                        onStyleSelected(
                            it
                        )

                        val running =
                            liveState
                                .status ==
                            LiveAssistStatus
                                .RUNNING

                        if (
                            running
                        ) {
                            appContext
                                .startService(
                                    MediaProjectionAssistService
                                        .updateStyleIntent(
                                            context =
                                                appContext,
                                            styleKey =
                                                it.key
                                        )
                                )
                        }

                        matches =
                            emptyList()

                        rawOcrText =
                            ""

                        ocrLineCount =
                            0
                    }
                )
            }

            item {
                LiveAssistCard(
                    liveStatus =
                        liveState
                            .status,
                    message =
                        liveState
                            .message,
                    recognizedCount =
                        liveState
                            .recognizedCount,
                    hasOverlayPermission =
                        Settings
                            .canDrawOverlays(
                                context
                            ),
                    onStart = {
                        startProjectionRequest()
                    },
                    onStop = {
                        appContext
                            .startService(
                                MediaProjectionAssistService
                                    .stopIntent(
                                        appContext
                                    )
                            )
                    }
                )
            }

            item {
                GuideCard(
                    styleName =
                        selectedStyle
                            .label,
                    skillCount =
                        currentStyleData
                            ?.skills
                            ?.size
                            ?: 0,
                    isSample =
                        meetingData
                            .metadata
                            .isSample
                )
            }

            item {
                Text(
                    text =
                        "スクリーンショットOCR",
                    style =
                        MaterialTheme
                            .typography
                            .titleMedium,
                    fontWeight =
                        FontWeight.Bold
                )
            }

            item {
                Button(
                    onClick = {
                        picker.launch(
                            PickVisualMediaRequest(
                                ActivityResultContracts
                                    .PickVisualMedia
                                    .ImageOnly
                            )
                        )
                    },
                    enabled =
                        ocrStatus !=
                        OcrUiStatus
                            .READING,
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .height(
                                54.dp
                            )
                ) {
                    Icon(
                        imageVector =
                            Icons.Default
                                .ImageSearch,
                        contentDescription =
                            null
                    )

                    Spacer(
                        Modifier
                            .padding(
                                horizontal =
                                    5.dp
                            )
                    )

                    Text(
                        if (
                            selectedImageUriText ==
                            null
                        ) {
                            "スキル画面を選ぶ"
                        } else {
                            "別のスキル画面を選ぶ"
                        }
                    )
                }
            }

            item {
                OcrStatusCard(
                    status =
                        ocrStatus,
                    message =
                        statusMessage
                )
            }

            if (
                matches.isNotEmpty()
            ) {
                item {
                    ResultSummary(
                        matches
                    )
                }

                items(
                    items =
                        matches,
                    key = {
                        it.skillId
                    }
                ) { match ->
                    MatchCard(
                        match
                    )
                }
            }

            if (
                rawOcrText
                    .isNotBlank()
            ) {
                item {
                    RawOcrCard(
                        rawText =
                            rawOcrText,
                        lineCount =
                            ocrLineCount
                    )
                }
            }
        }
    }
}

@Composable
private fun LiveAssistCard(
    liveStatus:
        LiveAssistStatus,
    message:
        String,
    recognizedCount:
        Int,
    hasOverlayPermission:
        Boolean,
    onStart:
        () -> Unit,
    onStop:
        () -> Unit
) {
    Card(
        modifier =
            Modifier
                .fillMaxWidth(),
        colors =
            CardDefaults
                .cardColors(
                    containerColor =
                        MaterialTheme
                            .colorScheme
                            .primaryContainer
                )
    ) {
        Column(
            modifier =
                Modifier
                    .padding(
                        16.dp
                    )
        ) {
            Row(
                verticalAlignment =
                    Alignment
                        .CenterVertically
            ) {
                Icon(
                    imageVector =
                        Icons.Default
                            .Layers,
                    contentDescription =
                        null
                )

                Spacer(
                    Modifier
                        .padding(
                            horizontal =
                                5.dp
                        )
                )

                Text(
                    text =
                        "リアルタイム表示",
                    style =
                        MaterialTheme
                            .typography
                            .titleMedium,
                    fontWeight =
                        FontWeight.Bold
                )
            }

            Spacer(
                Modifier.height(
                    8.dp
                )
            )

            Text(
                text =
                    message,
                style =
                    MaterialTheme
                        .typography
                        .bodyMedium
            )

            Spacer(
                Modifier.height(
                    6.dp
                )
            )

            Text(
                text =
                    "オーバーレイ権限: ${if (hasOverlayPermission) "OK" else "未許可"}",
                style =
                    MaterialTheme
                        .typography
                        .bodySmall
            )

            Spacer(
                Modifier.height(
                    4.dp
                )
            )

            Text(
                text =
                    "開始時のAndroid共有画面では「画面全体」を選ぶと、S/A/B表示位置が最も安定します。",
                style =
                    MaterialTheme
                        .typography
                        .bodySmall
            )

            if (
                liveStatus ==
                LiveAssistStatus
                    .RUNNING
            ) {
                Text(
                    text =
                        "現在表示: ${recognizedCount}件",
                    style =
                        MaterialTheme
                            .typography
                            .bodySmall
                )
            }

            Spacer(
                Modifier.height(
                    12.dp
                )
            )

            if (
                liveStatus ==
                LiveAssistStatus
                    .RUNNING ||
                liveStatus ==
                LiveAssistStatus
                    .STARTING
            ) {
                OutlinedButton(
                    onClick =
                        onStop,
                    modifier =
                        Modifier
                            .fillMaxWidth()
                ) {
                    Icon(
                        imageVector =
                            Icons.Default
                                .StopCircle,
                        contentDescription =
                            null
                    )

                    Spacer(
                        Modifier
                            .padding(
                                horizontal =
                                    4.dp
                            )
                    )

                    Text(
                        "リアルタイムアシスト停止"
                    )
                }
            } else {
                Button(
                    onClick =
                        onStart,
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .height(
                                52.dp
                            )
                ) {
                    Icon(
                        imageVector =
                            Icons.Default
                                .CenterFocusStrong,
                        contentDescription =
                            null
                    )

                    Spacer(
                        Modifier
                            .padding(
                                horizontal =
                                    4.dp
                            )
                    )

                    Text(
                        "リアルタイムアシスト開始"
                    )
                }
            }
        }
    }
}

@Composable
private fun StyleSelector(
    selectedStyle:
        RunningStyle,
    onStyleSelected:
        (RunningStyle) -> Unit
) {
    Column {
        Text(
            text =
                "判定する脚質",
            style =
                MaterialTheme
                    .typography
                    .labelLarge,
            fontWeight =
                FontWeight
                    .SemiBold
        )

        Spacer(
            Modifier.height(
                8.dp
            )
        )

        Row(
            modifier =
                Modifier
                    .fillMaxWidth(),
            horizontalArrangement =
                Arrangement
                    .spacedBy(
                        8.dp
                    )
        ) {
            RunningStyle
                .entries
                .forEach {
                    style ->
                    FilterChip(
                        selected =
                            style ==
                            selectedStyle,
                        onClick = {
                            onStyleSelected(
                                style
                            )
                        },
                        modifier =
                            Modifier
                                .weight(
                                    1f
                                ),
                        label = {
                            Text(
                                style.label
                            )
                        }
                    )
                }
        }
    }
}

@Composable
private fun GuideCard(
    styleName:
        String,
    skillCount:
        Int,
    isSample:
        Boolean
) {
    Card(
        modifier =
            Modifier
                .fillMaxWidth(),
        colors =
            CardDefaults
                .cardColors(
                    containerColor =
                        MaterialTheme
                            .colorScheme
                            .surfaceContainer
                )
    ) {
        Column(
            modifier =
                Modifier
                    .padding(
                        16.dp
                    )
        ) {
            Text(
                text =
                    "判定対象",
                style =
                    MaterialTheme
                        .typography
                        .titleMedium,
                fontWeight =
                    FontWeight.Bold
            )

            Spacer(
                Modifier.height(
                    6.dp
                )
            )

            Text(
                text =
                    "${styleName} / ${skillCount}スキルをaliases照合します。",
                style =
                    MaterialTheme
                        .typography
                        .bodyMedium
            )

            if (
                isSample
            ) {
                Spacer(
                    Modifier.height(
                        8.dp
                    )
                )

                Text(
                    text =
                        "※ 現在の同梱JSONはサンプルです。実攻略JSONへ更新後に実スキルを判定します。",
                    style =
                        MaterialTheme
                            .typography
                            .bodySmall,
                    color =
                        MaterialTheme
                            .colorScheme
                            .error
                )
            }
        }
    }
}

@Composable
private fun OcrStatusCard(
    status:
        OcrUiStatus,
    message:
        String
) {
    Surface(
        modifier =
            Modifier
                .fillMaxWidth(),
        shape =
            MaterialTheme
                .shapes
                .large,
        color =
            when (
                status
            ) {
                OcrUiStatus
                    .SUCCESS ->
                    MaterialTheme
                        .colorScheme
                        .primaryContainer

                OcrUiStatus
                    .ERROR ->
                    MaterialTheme
                        .colorScheme
                        .errorContainer

                else ->
                    MaterialTheme
                        .colorScheme
                        .surfaceContainerLow
            }
    ) {
        Row(
            modifier =
                Modifier
                    .padding(
                        14.dp
                    ),
            verticalAlignment =
                Alignment
                    .CenterVertically
        ) {
            if (
                status ==
                OcrUiStatus
                    .READING
            ) {
                CircularProgressIndicator(
                    modifier =
                        Modifier
                            .height(
                                22.dp
                            ),
                    strokeWidth =
                        2.dp
                )

                Spacer(
                    Modifier
                        .padding(
                            horizontal =
                                5.dp
                        )
                )
            } else {
                Icon(
                    imageVector =
                        Icons.Default
                            .CenterFocusStrong,
                    contentDescription =
                        null
                )

                Spacer(
                    Modifier
                        .padding(
                            horizontal =
                                5.dp
                        )
                )
            }

            Text(
                text =
                    message,
                style =
                    MaterialTheme
                        .typography
                        .bodyMedium
            )
        }
    }
}

@Composable
private fun ResultSummary(
    matches:
        List<SkillOcrMatch>
) {
    val counts =
        matches
            .groupingBy {
                it.grade
                    .uppercase()
            }
            .eachCount()

    Card(
        modifier =
            Modifier
                .fillMaxWidth()
    ) {
        Row(
            modifier =
                Modifier
                    .padding(
                        14.dp
                    ),
            horizontalArrangement =
                Arrangement
                    .spacedBy(
                        14.dp
                    )
        ) {
            Text(
                "S: ${counts["S"] ?: 0}",
                fontWeight =
                    FontWeight.Bold
            )

            Text(
                "A: ${counts["A"] ?: 0}",
                fontWeight =
                    FontWeight.Bold
            )

            Text(
                "B: ${counts["B"] ?: 0}",
                fontWeight =
                    FontWeight.Bold
            )
        }
    }
}

@Composable
private fun MatchCard(
    match:
        SkillOcrMatch
) {
    Card(
        modifier =
            Modifier
                .fillMaxWidth()
    ) {
        Column(
            modifier =
                Modifier
                    .padding(
                        15.dp
                    )
        ) {
            Row(
                verticalAlignment =
                    Alignment
                        .CenterVertically
            ) {
                GradeBadge(
                    match.grade
                )

                Spacer(
                    Modifier
                        .padding(
                            horizontal =
                                5.dp
                        )
                )

                Column(
                    modifier =
                        Modifier
                            .weight(
                                1f
                            )
                ) {
                    Text(
                        text =
                            match
                                .skillName,
                        fontWeight =
                            FontWeight.Bold
                    )

                    Text(
                        text =
                            categoryLabel(
                                match.category
                            ),
                        style =
                            MaterialTheme
                                .typography
                                .labelMedium
                    )
                }

                Text(
                    text =
                        "${(match.confidence * 100).toInt()}%"
                )
            }

            match.reason
                ?.takeIf {
                    it.isNotBlank()
                }
                ?.let {
                    Spacer(
                        Modifier.height(
                            8.dp
                        )
                    )

                    Text(
                        it
                    )
                }

            Spacer(
                Modifier.height(
                    8.dp
                )
            )

            HorizontalDivider()

            Spacer(
                Modifier.height(
                    8.dp
                )
            )

            Text(
                text =
                    "OCR: ${match.recognizedText}",
                style =
                    MaterialTheme
                        .typography
                        .bodySmall
            )

            Text(
                text =
                    "一致: ${match.matchedAlias}",
                style =
                    MaterialTheme
                        .typography
                        .bodySmall
            )
        }
    }
}

@Composable
private fun GradeBadge(
    grade:
        String
) {
    Surface(
        shape =
            MaterialTheme
                .shapes
                .medium,
        color =
            MaterialTheme
                .colorScheme
                .secondaryContainer
    ) {
        Text(
            text =
                grade.uppercase(),
            modifier =
                Modifier
                    .padding(
                        horizontal =
                            11.dp,
                        vertical =
                            7.dp
                    ),
            fontWeight =
                FontWeight
                    .ExtraBold
        )
    }
}

@Composable
private fun RawOcrCard(
    rawText:
        String,
    lineCount:
        Int
) {
    var expanded
        by rememberSaveable {
            mutableStateOf(
                false
            )
        }

    Card(
        modifier =
            Modifier
                .fillMaxWidth()
    ) {
        Column(
            modifier =
                Modifier
                    .padding(
                        14.dp
                    )
        ) {
            OutlinedButton(
                onClick = {
                    expanded =
                        !expanded
                }
            ) {
                Text(
                    if (
                        expanded
                    ) {
                        "OCR生テキストを閉じる"
                    } else {
                        "OCR生テキストを見る ($lineCount 行)"
                    }
                )
            }

            if (
                expanded
            ) {
                Spacer(
                    Modifier.height(
                        10.dp
                    )
                )

                Text(
                    text =
                        rawText,
                    style =
                        MaterialTheme
                            .typography
                            .bodySmall
                )
            }
        }
    }
}

@Composable
private fun AssistBottomNavigation(
    onNavigate:
        (AppDestination) -> Unit
) {
    NavigationBar {
        NavigationBarItem(
            selected =
                false,
            onClick = {
                onNavigate(
                    AppDestination.HOME
                )
            },
            icon = {
                Icon(
                    Icons.Default
                        .Home,
                    contentDescription =
                        null
                )
            },
            label = {
                Text(
                    "ホーム"
                )
            }
        )

        NavigationBarItem(
            selected =
                false,
            onClick = {
                onNavigate(
                    AppDestination.SKILLS
                )
            },
            icon = {
                Icon(
                    Icons.Default
                        .Search,
                    contentDescription =
                        null
                )
            },
            label = {
                Text(
                    "スキル"
                )
            }
        )

        NavigationBarItem(
            selected =
                true,
            onClick = {},
            icon = {
                Icon(
                    Icons.Default
                        .CenterFocusStrong,
                    contentDescription =
                        null
                )
            },
            label = {
                Text(
                    "アシスト"
                )
            }
        )

        NavigationBarItem(
            selected =
                false,
            onClick = {
                onNavigate(
                    AppDestination.SETTINGS
                )
            },
            icon = {
                Icon(
                    Icons.Default
                        .Settings,
                    contentDescription =
                        null
                )
            },
            label = {
                Text(
                    "設定"
                )
            }
        )
    }
}
