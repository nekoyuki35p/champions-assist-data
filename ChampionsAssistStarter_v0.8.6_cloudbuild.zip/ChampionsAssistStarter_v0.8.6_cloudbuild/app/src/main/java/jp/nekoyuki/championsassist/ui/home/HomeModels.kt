package jp.nekoyuki.championsassist.ui.home

import jp.nekoyuki.championsassist.data.model.ChampionsMeetingData
import jp.nekoyuki.championsassist.data.model.RunningStyleData

enum class RunningStyle(
    val key: String,
    val label: String
) {
    NIGE("nige", "逃げ"),
    SENKO("senko", "先行"),
    SASHI("sashi", "差し"),
    OIKOMI("oikomi", "追込")
}


enum class RemoteUpdateUiStatus {
    IDLE,
    CHECKING,
    LATEST,
    UPDATED,
    USING_CACHE,
    USING_FALLBACK,
    DISABLED,
    ERROR
}

data class RemoteUpdateUiState(
    val status: RemoteUpdateUiStatus,
    val message: String,
    val canRetry: Boolean = true
)

data class TargetStats(
    val speed: String,
    val stamina: String,
    val power: String,
    val guts: String,
    val wisdom: String
)

enum class ContentStatus {
    LATEST,
    UPDATE_AVAILABLE,
    WAITING_ARTICLE,
    ERROR
}

data class ChampionsMeeting(
    val title: String,
    val venue: String,
    val surface: String,
    val distance: Int,
    val direction: String,
    val season: String,
    val weather: String?,
    val groundCondition: String?,
    val updatedAt: String,
    val sourceName: String,
    val isSample: Boolean
)

data class StyleSummary(
    val runningStyle: RunningStyle,
    val targetStats: TargetStats
)

data class StyleContentStatus(
    val runningStyle: RunningStyle,
    val status: ContentStatus
)

data class HomeUiState(
    val meeting: ChampionsMeeting,
    val selectedStyle: RunningStyle?,
    val styleSummary: StyleSummary?,
    val courseStatus: ContentStatus,
    val styleStatuses: List<StyleContentStatus>,
    val isRefreshing: Boolean = false
)

fun ChampionsMeetingData.toHomeUiState(
    selectedStyle: RunningStyle?
): HomeUiState {
    val selectedData = selectedStyle?.let {
        runningStyles[it.key]
    }

    val newestUpdate = runningStyles.values
        .mapNotNull { it.updatedAt }
        .maxOrNull()
        ?: metadata.generatedAt
        ?: "更新日時不明"

    val sourceName = metadata.sourceSite
        ?: sources.firstOrNull()?.siteName
        ?: "情報源未設定"

    return HomeUiState(
        meeting = ChampionsMeeting(
            title = meeting.title,
            venue = course.venue,
            surface = surfaceLabel(course.surface),
            distance = course.distance,
            direction = directionLabel(course.direction),
            season = seasonLabel(course.season),
            weather = weatherLabel(course.weather),
            groundCondition = groundLabel(course.groundCondition),
            updatedAt = newestUpdate,
            sourceName = sourceName,
            isSample = metadata.isSample
        ),
        selectedStyle = selectedStyle,
        styleSummary = selectedStyle?.let { style ->
            selectedData?.let { data ->
                StyleSummary(
                    runningStyle = style,
                    targetStats = data.toTargetStats()
                )
            }
        },
        courseStatus = ContentStatus.LATEST,
        styleStatuses = RunningStyle.entries.map { style ->
            StyleContentStatus(
                runningStyle = style,
                status = contentStatus(
                    runningStyles[style.key]?.contentStatus
                )
            )
        }
    )
}

private fun RunningStyleData.toTargetStats(): TargetStats {
    fun display(
        raw: String?,
        value: Int?
    ): String = raw?.takeIf { it.isNotBlank() }
        ?: value?.let { "$it+" }
        ?: "―"

    return TargetStats(
        speed = display(targetStats.speed?.display, targetStats.speed?.value),
        stamina = display(targetStats.stamina?.display, targetStats.stamina?.value),
        power = display(targetStats.power?.display, targetStats.power?.value),
        guts = display(targetStats.guts?.display, targetStats.guts?.value),
        wisdom = display(targetStats.wisdom?.display, targetStats.wisdom?.value)
    )
}

private fun contentStatus(raw: String?): ContentStatus =
    when (raw) {
        "ready" -> ContentStatus.LATEST
        "partial" -> ContentStatus.UPDATE_AVAILABLE
        "waiting_article" -> ContentStatus.WAITING_ARTICLE
        else -> ContentStatus.ERROR
    }

private fun surfaceLabel(value: String): String =
    when (value) {
        "turf" -> "芝"
        "dirt" -> "ダート"
        else -> value
    }

private fun directionLabel(value: String): String =
    when (value) {
        "left" -> "左回り"
        "right" -> "右回り"
        "straight" -> "直線"
        else -> "不明"
    }

private fun seasonLabel(value: String): String =
    when (value) {
        "spring" -> "春"
        "summer" -> "夏"
        "autumn" -> "秋"
        "winter" -> "冬"
        else -> "不明"
    }

private fun weatherLabel(value: String?): String? =
    when (value) {
        null -> null
        "sunny" -> "晴"
        "cloudy" -> "曇"
        "rain" -> "雨"
        "snow" -> "雪"
        "unknown" -> null
        else -> value
    }

private fun groundLabel(value: String?): String? =
    when (value) {
        null -> null
        "firm" -> "良"
        "good" -> "稍重"
        "soft" -> "重"
        "heavy" -> "不良"
        "unknown" -> null
        else -> value
    }
