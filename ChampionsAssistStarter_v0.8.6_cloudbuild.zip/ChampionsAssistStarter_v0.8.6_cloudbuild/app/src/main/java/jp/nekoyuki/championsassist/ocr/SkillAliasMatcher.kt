package jp.nekoyuki.championsassist.ocr

import jp.nekoyuki.championsassist.data.model.SkillData
import java.text.Normalizer
import kotlin.math.max

data class SkillOcrMatch(
    val skillId: String,
    val skillName: String,
    val grade: String,
    val category: String,
    val reason: String?,
    val matchedAlias: String,
    val recognizedText: String,
    val confidence: Float,
    val left: Int?,
    val top: Int?,
    val right: Int?,
    val bottom: Int?
)

class SkillAliasMatcher {

    fun match(
        recognizedLines: List<OcrLine>,
        skills: List<SkillData>,
        minConfidence: Float = DEFAULT_MATCH_THRESHOLD
    ): List<SkillOcrMatch> {
        if (
            recognizedLines.isEmpty() ||
            skills.isEmpty()
        ) {
            return emptyList()
        }

        val candidates = recognizedLines
            .map { line ->
                Candidate(
                    line = line,
                    normalized = normalize(
                        line.text
                    )
                )
            }
            .filter {
                it.normalized.isNotBlank()
            }

        val bestBySkill =
            linkedMapOf<String, SkillOcrMatch>()

        for (skill in skills) {
            val aliases = buildList {
                add(skill.name)
                addAll(skill.aliases)
            }
                .distinct()
                .filter {
                    it.isNotBlank()
                }

            var bestMatch:
                SkillOcrMatch? = null

            for (alias in aliases) {
                val normalizedAlias =
                    normalize(alias)

                if (
                    normalizedAlias.length < 2
                ) {
                    continue
                }

                for (
                    candidate in candidates
                ) {
                    val score =
                        similarityScore(
                            alias =
                                normalizedAlias,
                            candidate =
                                candidate
                                    .normalized
                        )

                    if (
                        score <
                        minConfidence
                    ) {
                        continue
                    }

                    val line =
                        candidate.line

                    val current =
                        SkillOcrMatch(
                            skillId =
                                skill.id,
                            skillName =
                                skill.name,
                            grade =
                                skill.grade,
                            category =
                                skill.category,
                            reason =
                                skill.reason,
                            matchedAlias =
                                alias,
                            recognizedText =
                                line.text,
                            confidence =
                                score,
                            left =
                                line.left,
                            top =
                                line.top,
                            right =
                                line.right,
                            bottom =
                                line.bottom
                        )

                    if (
                        bestMatch == null ||
                        current.confidence >
                        bestMatch.confidence
                    ) {
                        bestMatch =
                            current
                    }
                }
            }

            if (
                bestMatch != null
            ) {
                bestBySkill[
                    skill.id
                ] = bestMatch
            }
        }

        return bestBySkill
            .values
            .sortedWith(
                compareByDescending<
                    SkillOcrMatch
                > {
                    gradeRank(
                        it.grade
                    )
                }
                    .thenByDescending {
                        it.confidence
                    }
                    .thenBy {
                        it.skillName
                    }
            )
    }

    internal fun normalize(
        value: String
    ): String {
        var text =
            Normalizer.normalize(
                value,
                Normalizer.Form.NFKC
            )

        text = text
            .replace('◯', '○')
            .replace('〇', '○')
            .replace('●', '○')
            .lowercase()

        return text.replace(
            Regex(
                """[\s　・･:：,，.。!！?？"'“”‘’`\[\]【】{}｛｝<>＜＞「」『』]"""
            ),
            ""
        )
    }

    private fun similarityScore(
        alias: String,
        candidate: String
    ): Float {
        if (
            alias.isBlank() ||
            candidate.isBlank()
        ) {
            return 0f
        }

        if (
            alias == candidate
        ) {
            return 1f
        }

        if (
            alias.length >= 2 &&
            candidate.startsWith(alias)
        ) {
            val suffix =
                candidate
                    .removePrefix(alias)

            if (
                suffix.isNotEmpty() &&
                suffix.matches(
                    Regex(
                        """[0-9pt]+"""
                    )
                )
            ) {
                return 0.98f
            }
        }

        if (
            alias.length >= 3 &&
            candidate.contains(alias)
        ) {
            return 0.98f
        }

        if (
            candidate.length >= 3 &&
            alias.contains(candidate) &&
            candidate.length.toFloat() /
            alias.length.toFloat() >=
            0.78f
        ) {
            return 0.90f
        }

        if (
            alias.length <
            MIN_FUZZY_LENGTH ||
            candidate.length <
            MIN_FUZZY_LENGTH
        ) {
            return 0f
        }

        val maxLength =
            max(
                alias.length,
                candidate.length
            )

        if (
            maxLength >
            max(
                alias.length * 2,
                alias.length + 8
            )
        ) {
            return 0f
        }

        val distance =
            levenshteinDistance(
                alias,
                candidate
            )

        return 1f -
            distance.toFloat() /
            maxLength.toFloat()
    }

    private fun levenshteinDistance(
        left: String,
        right: String
    ): Int {
        if (
            left == right
        ) {
            return 0
        }

        if (
            left.isEmpty()
        ) {
            return right.length
        }

        if (
            right.isEmpty()
        ) {
            return left.length
        }

        var previous =
            IntArray(
                right.length + 1
            ) {
                it
            }

        var current =
            IntArray(
                right.length + 1
            )

        for (
            i in left.indices
        ) {
            current[0] = i + 1

            for (
                j in right.indices
            ) {
                val insertion =
                    current[j] + 1

                val deletion =
                    previous[j + 1] +
                    1

                val substitution =
                    previous[j] +
                    if (
                        left[i] ==
                        right[j]
                    ) {
                        0
                    } else {
                        1
                    }

                current[j + 1] =
                    minOf(
                        insertion,
                        deletion,
                        substitution
                    )
            }

            val swap =
                previous
            previous =
                current
            current =
                swap
        }

        return previous[
            right.length
        ]
    }

    private fun gradeRank(
        grade: String
    ): Int =
        when (
            grade.uppercase()
        ) {
            "S" -> 100
            "A" -> 70
            "B" -> 40
            "C" -> 20
            else -> 0
        }

    private data class Candidate(
        val line: OcrLine,
        val normalized: String
    )

    private companion object {
        const val DEFAULT_MATCH_THRESHOLD =
            0.82f

        const val MIN_FUZZY_LENGTH =
            4
    }
}
