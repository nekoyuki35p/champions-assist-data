package jp.nekoyuki.championsassist.debug

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DebugLog(
    context: Context
) {
    private val directory =
        File(
            context.filesDir,
            "debug"
        )

    private val file =
        File(
            directory,
            "live_assist.log"
        )

    @Synchronized
    fun append(
        message: String
    ) {
        directory.mkdirs()

        rotateIfNeeded()

        val timestamp =
            SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss.SSS",
                Locale.JAPAN
            ).format(
                Date()
            )

        file.appendText(
            "[$timestamp] $message\n",
            Charsets.UTF_8
        )
    }

    @Synchronized
    fun readRecent(
        maxLines: Int = 100
    ): String {
        if (
            !file.isFile
        ) {
            return "ログはまだありません。"
        }

        return file
            .readLines(
                Charsets.UTF_8
            )
            .takeLast(
                maxLines
                    .coerceAtLeast(1)
            )
            .joinToString(
                "\n"
            )
    }

    @Synchronized
    fun clear() {
        if (
            file.exists()
        ) {
            file.writeText(
                "",
                Charsets.UTF_8
            )
        }
    }

    fun path(): String =
        file.absolutePath

    private fun rotateIfNeeded() {
        if (
            !file.isFile ||
            file.length() <
            MAX_BYTES
        ) {
            return
        }

        val recent =
            file.readLines(
                Charsets.UTF_8
            )
                .takeLast(
                    250
                )
                .joinToString(
                    "\n"
                )

        file.writeText(
            recent + "\n",
            Charsets.UTF_8
        )
    }

    private companion object {
        const val MAX_BYTES =
            512 * 1024L
    }
}
