package jp.nekoyuki.championsassist.ocr

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

class JapaneseOcrRecognizer(
    private val context: Context
) {
    /*
     * v0.8.5:
     * Keep one ML Kit recognizer alive instead of constructing and closing
     * it on every scan. This removes a large amount of per-frame overhead.
     */
    private val recognizer: TextRecognizer =
        TextRecognition.getClient(
            JapaneseTextRecognizerOptions
                .Builder()
                .build()
        )

    suspend fun recognize(
        imageUri: Uri
    ): OcrResult {
        val image =
            withContext(
                Dispatchers.IO
            ) {
                InputImage.fromFilePath(
                    context,
                    imageUri
                )
            }

        return process(
            image = image,
            imageWidth = image.width,
            imageHeight = image.height
        )
    }

    suspend fun recognize(
        bitmap: Bitmap
    ): OcrResult {
        val image =
            InputImage.fromBitmap(
                bitmap,
                0
            )

        return process(
            image = image,
            imageWidth = bitmap.width,
            imageHeight = bitmap.height
        )
    }

    fun close() {
        recognizer.close()
    }

    private suspend fun process(
        image: InputImage,
        imageWidth: Int,
        imageHeight: Int
    ): OcrResult =
        suspendCoroutine { continuation ->
            recognizer
                .process(image)
                .addOnSuccessListener { text ->
                    val lines =
                        text.textBlocks
                            .flatMap { block ->
                                block.lines.map { line ->
                                    val box =
                                        line.boundingBox

                                    OcrLine(
                                        text =
                                            line.text
                                                .trim(),
                                        left =
                                            box?.left,
                                        top =
                                            box?.top,
                                        right =
                                            box?.right,
                                        bottom =
                                            box?.bottom
                                    )
                                }
                            }
                            .filter {
                                it.text
                                    .isNotBlank()
                            }

                    continuation.resume(
                        OcrResult(
                            rawText =
                                text.text,
                            lines =
                                lines,
                            imageWidth =
                                imageWidth,
                            imageHeight =
                                imageHeight
                        )
                    )
                }
                .addOnFailureListener { error ->
                    continuation
                        .resumeWithException(
                            error
                        )
                }
        }
}
