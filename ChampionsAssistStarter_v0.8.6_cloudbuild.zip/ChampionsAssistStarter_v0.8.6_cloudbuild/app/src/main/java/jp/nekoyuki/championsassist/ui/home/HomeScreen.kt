package jp.nekoyuki.championsassist.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.nekoyuki.championsassist.data.update.DataOrigin
import jp.nekoyuki.championsassist.data.update.RemoteUpdateConfig
import jp.nekoyuki.championsassist.data.update.RemoteUpdateResult
import kotlinx.coroutines.launch
import jp.nekoyuki.championsassist.data.model.ChampionsMeetingData
import jp.nekoyuki.championsassist.data.repository.ChampionsMeetingRepository
import jp.nekoyuki.championsassist.ui.AppDestination
import jp.nekoyuki.championsassist.ui.assist.AssistScreen
import jp.nekoyuki.championsassist.ui.skills.SkillScreen
import jp.nekoyuki.championsassist.ui.settings.SettingsScreen
import jp.nekoyuki.championsassist.ui.skills.toSkillScreenUiState
import jp.nekoyuki.championsassist.ui.theme.ChampionsAssistTheme

@Composable
fun HomeRoute() {
    val context = LocalContext.current.applicationContext
    val repository = remember {
        ChampionsMeetingRepository(context)
    }
    val scope = rememberCoroutineScope()

    var selectedStyleName by rememberSaveable {
        mutableStateOf(RunningStyle.SASHI.name)
    }

    var destinationName by rememberSaveable {
        mutableStateOf(AppDestination.HOME.name)
    }

    var meetingData by remember {
        mutableStateOf<ChampionsMeetingData?>(null)
    }

    var loadError by remember {
        mutableStateOf<String?>(null)
    }

    var remoteConfig by remember {
        mutableStateOf<RemoteUpdateConfig?>(null)
    }

    var updateState by remember {
        mutableStateOf(
            RemoteUpdateUiState(
                status = RemoteUpdateUiStatus.IDLE,
                message = "端末データを読み込み中…",
                canRetry = false
            )
        )
    }

    suspend fun refreshRemote() {
        val config = remoteConfig
            ?: runCatching {
                repository.loadRemoteConfig()
            }.getOrElse {
                updateState = RemoteUpdateUiState(
                    status = RemoteUpdateUiStatus.ERROR,
                    message = "更新設定を読み込めませんでした。",
                    canRetry = true
                )
                return
            }.also {
                remoteConfig = it
            }

        if (config.latestJsonUrl.isBlank()) {
            updateState = RemoteUpdateUiState(
                status = RemoteUpdateUiStatus.DISABLED,
                message = "latest.jsonの公開URLが未設定です。",
                canRetry = false
            )
            return
        }

        updateState = RemoteUpdateUiState(
            status = RemoteUpdateUiStatus.CHECKING,
            message = "最新の攻略データを確認中…",
            canRetry = false
        )

        when (
            val result = repository.refreshFromRemote(config)
        ) {
            is RemoteUpdateResult.Updated -> {
                meetingData = result.data
                updateState = RemoteUpdateUiState(
                    status = RemoteUpdateUiStatus.UPDATED,
                    message = "攻略データを更新しました (${result.dataVersion})",
                    canRetry = true
                )
            }

            is RemoteUpdateResult.Latest -> {
                updateState = RemoteUpdateUiState(
                    status = RemoteUpdateUiStatus.LATEST,
                    message = "攻略データは最新です (${result.dataVersion})",
                    canRetry = true
                )
            }

            RemoteUpdateResult.NotModified -> {
                updateState = RemoteUpdateUiState(
                    status = RemoteUpdateUiStatus.LATEST,
                    message = "攻略データは最新です。",
                    canRetry = true
                )
            }

            RemoteUpdateResult.Disabled -> {
                updateState = RemoteUpdateUiState(
                    status = RemoteUpdateUiStatus.DISABLED,
                    message = "ネット更新は未設定です。",
                    canRetry = false
                )
            }

            is RemoteUpdateResult.Failed -> {
                updateState = RemoteUpdateUiState(
                    status = RemoteUpdateUiStatus.ERROR,
                    message = "${result.message} 端末保存データを継続使用します。",
                    canRetry = true
                )
            }
        }
    }

    LaunchedEffect(Unit) {
        runCatching {
            repository.loadInitialData()
        }.onSuccess { loaded ->
            meetingData = loaded.data
            loadError = null

            updateState =
                when (loaded.origin) {
                    DataOrigin.CACHE -> {
                        RemoteUpdateUiState(
                            status = RemoteUpdateUiStatus.USING_CACHE,
                            message = "端末保存済みデータを表示しています。",
                            canRetry = true
                        )
                    }

                    DataOrigin.ASSET -> {
                        RemoteUpdateUiState(
                            status = RemoteUpdateUiStatus.USING_FALLBACK,
                            message = "アプリ同梱データを表示しています。",
                            canRetry = true
                        )
                    }
                }

            val config = runCatching {
                repository.loadRemoteConfig()
            }.getOrNull()

            remoteConfig = config

            if (
                config != null &&
                config.autoRefreshOnLaunch
            ) {
                refreshRemote()
            }
        }.onFailure {
            loadError =
                it.message
                    ?: "攻略データを読み込めませんでした。"
        }
    }

    val selectedStyle = runCatching {
        RunningStyle.valueOf(selectedStyleName)
    }.getOrDefault(RunningStyle.SASHI)

    val destination = runCatching {
        AppDestination.valueOf(destinationName)
    }.getOrDefault(AppDestination.HOME)

    val navigate: (AppDestination) -> Unit = {
        destinationName = it.name
    }

    val requestRefresh: () -> Unit = {
        scope.launch {
            refreshRemote()
        }
        Unit
    }

    when {
        meetingData != null -> {
            val data = meetingData!!

            when (destination) {
                AppDestination.HOME -> {
                    HomeScreen(
                        state = data.toHomeUiState(
                            selectedStyle
                        ),
                        updateState = updateState,
                        onRefresh = requestRefresh,
                        onStyleSelected = {
                            selectedStyleName = it.name
                        },
                        onOpenStyleGuide = {
                            destinationName =
                                AppDestination.SKILLS.name
                        },
                        onStartAssist = {
                            destinationName =
                                AppDestination.ASSIST.name
                        },
                        onOpenSettings = {
                            destinationName =
                                AppDestination.SETTINGS.name
                        },
                        onOpenSource = {},
                        onOpenDataDetails = {},
                        onNavigate = navigate
                    )
                }

                AppDestination.SKILLS -> {
                    SkillScreen(
                        state = data.toSkillScreenUiState(
                            selectedStyle
                        ),
                        onStyleSelected = {
                            selectedStyleName = it.name
                        },
                        onBack = {
                            destinationName =
                                AppDestination.HOME.name
                        },
                        onNavigate = navigate
                    )
                }

                AppDestination.ASSIST -> {
                    AssistScreen(
                        meetingData = data,
                        selectedStyle = selectedStyle,
                        onStyleSelected = {
                            selectedStyleName = it.name
                        },
                        onBack = {
                            destinationName =
                                AppDestination.HOME.name
                        },
                        onNavigate = navigate
                    )
                }

                AppDestination.SETTINGS -> {
                    SettingsScreen(
                        onBack = {
                            destinationName =
                                AppDestination.HOME.name
                        },
                        onNavigate = navigate
                    )
                }
            }
        }

        loadError != null -> {
            DataLoadErrorScreen(
                message = loadError!!
            )
        }

        else -> {
            InitialLoadingScreen()
        }
    }
}

@Composable
private fun PlaceholderDestinationScreen(
    title: String,
    message: String,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = message,
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(Modifier.height(18.dp))
        Button(onClick = onBack) {
            Text("ホームへ戻る")
        }
    }
}

@Composable
private fun InitialLoadingScreen() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text("攻略データを読み込み中…")
    }
}

@Composable
private fun DataLoadErrorScreen(
    message: String
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "攻略データの読み込みに失敗しました。\n$message",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    state: HomeUiState,
    updateState: RemoteUpdateUiState,
    onRefresh: () -> Unit,
    onStyleSelected: (RunningStyle) -> Unit,
    onOpenStyleGuide: () -> Unit,
    onStartAssist: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenSource: () -> Unit,
    onOpenDataDetails: () -> Unit,
    onNavigate: (AppDestination) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Champions Assist",
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "設定"
                        )
                    }
                }
            )
        },
        bottomBar = {
            HomeBottomNavigation(onNavigate = onNavigate)
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 12.dp,
                bottom = 24.dp
            ),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item {
                MeetingCard(
                    meeting = state.meeting,
                    status = state.courseStatus,
                    updateState = updateState,
                    onRefresh = onRefresh,
                    onOpenSource = onOpenSource
                )
            }

            item {
                StyleSection(
                    selectedStyle = state.selectedStyle,
                    summary = state.styleSummary,
                    onStyleSelected = onStyleSelected,
                    onOpenStyleGuide = onOpenStyleGuide
                )
            }

            item {
                AssistCard(
                    meetingTitle = state.meeting.title,
                    selectedStyle = state.selectedStyle,
                    onStartAssist = onStartAssist
                )
            }

            item {
                DataStatusSection(
                    courseStatus = state.courseStatus,
                    styleStatuses = state.styleStatuses,
                    onOpenDetails = onOpenDataDetails
                )
            }
        }
    }
}

@Composable
private fun MeetingCard(
    meeting: ChampionsMeeting,
    status: ContentStatus,
    updateState: RemoteUpdateUiState,
    onRefresh: () -> Unit,
    onOpenSource: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "CURRENT CHAMPIONS MEETING",
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.primary
            )

            if (meeting.isSample) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "SAMPLE DATA",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Spacer(Modifier.height(6.dp))

            Text(
                text = meeting.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(Modifier.height(12.dp))

            Text(
                text = "${meeting.venue}・${meeting.surface} ${meeting.distance}m",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(Modifier.height(10.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ConditionChip(meeting.direction)
                ConditionChip(meeting.season)
                meeting.weather?.let { ConditionChip(it) }
                meeting.groundCondition?.let { ConditionChip(it) }
            }

            Spacer(Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusIcon(status)

                Spacer(Modifier.padding(horizontal = 4.dp))

                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "攻略データ ${statusLabel(status)}",
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = meeting.updatedAt,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Spacer(Modifier.height(6.dp))

            OutlinedButton(
                onClick = onOpenSource,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "出典：${meeting.sourceName}",
                    style = MaterialTheme.typography.labelMedium
                )
            }

            Spacer(Modifier.height(12.dp))
            HorizontalDivider()
            Spacer(Modifier.height(12.dp))

            RemoteUpdateRow(
                state = updateState,
                onRefresh = onRefresh
            )
        }
    }
}

@Composable
private fun RemoteUpdateRow(
    state: RemoteUpdateUiState,
    onRefresh: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        when (state.status) {
            RemoteUpdateUiStatus.CHECKING -> {
                CircularProgressIndicator(
                    modifier = Modifier
                        .padding(end = 10.dp)
                        .height(22.dp),
                    strokeWidth = 2.dp
                )
            }

            RemoteUpdateUiStatus.LATEST,
            RemoteUpdateUiStatus.UPDATED -> {
                Icon(
                    imageVector = Icons.Default.CloudDone,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.padding(horizontal = 4.dp))
            }

            RemoteUpdateUiStatus.ERROR -> {
                Icon(
                    imageVector = Icons.Default.CloudOff,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error
                )
                Spacer(Modifier.padding(horizontal = 4.dp))
            }

            else -> {
                Icon(
                    imageVector = Icons.Default.CloudSync,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.padding(horizontal = 4.dp))
            }
        }

        Text(
            text = state.message,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodySmall
        )

        if (
            state.canRetry &&
            state.status != RemoteUpdateUiStatus.CHECKING
        ) {
            IconButton(
                onClick = onRefresh
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "攻略データを更新"
                )
            }
        }
    }
}

@Composable
private fun ConditionChip(text: String) {
    Surface(
        shape = MaterialTheme.shapes.extraLarge,
        color = MaterialTheme.colorScheme.secondaryContainer
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            style = MaterialTheme.typography.labelMedium
        )
    }
}

@Composable
private fun StyleSection(
    selectedStyle: RunningStyle?,
    summary: StyleSummary?,
    onStyleSelected: (RunningStyle) -> Unit,
    onOpenStyleGuide: () -> Unit
) {
    Column {
        Text(
            text = "脚質を選択",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            RunningStyle.entries.forEach { style ->
                val selected = style == selectedStyle

                if (selected) {
                    Button(
                        onClick = { onStyleSelected(style) },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 6.dp)
                    ) {
                        Text(style.label)
                    }
                } else {
                    OutlinedButton(
                        onClick = { onStyleSelected(style) },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 6.dp)
                    ) {
                        Text(style.label)
                    }
                }
            }
        }

        summary?.let {
            Spacer(Modifier.height(12.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp)
                ) {
                    Text(
                        text = "${it.runningStyle.label}・目標ステータス",
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(Modifier.height(12.dp))

                    StatsRow(it.targetStats)
                }
            }

            Spacer(Modifier.height(12.dp))

            Button(
                onClick = onOpenStyleGuide,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = MaterialTheme.shapes.large
            ) {
                Text("${it.runningStyle.label}の攻略を見る")
                Spacer(Modifier.weight(1f))
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null
                )
            }
        }
    }
}

@Composable
private fun StatsRow(stats: TargetStats) {
    val values = listOf(
        "SPD" to stats.speed,
        "STA" to stats.stamina,
        "POW" to stats.power,
        "GUT" to stats.guts,
        "WIS" to stats.wisdom
    )

    Row(
        modifier = Modifier.fillMaxWidth()
    ) {
        values.forEach { (label, value) ->
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = label,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = value,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun AssistCard(
    meetingTitle: String,
    selectedStyle: RunningStyle?,
    onStartAssist: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CenterFocusStrong,
                    contentDescription = null
                )
                Spacer(Modifier.padding(horizontal = 4.dp))
                Text(
                    text = "育成終了アシスト",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(8.dp))

            Text(
                text = "スキル取得画面を認識して、今回有効なスキルをハイライトします。",
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(Modifier.height(8.dp))

            Text(
                text = selectedStyle?.let {
                    "現在：$meetingTitle / ${it.label}"
                } ?: "脚質を選択してください",
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(Modifier.height(14.dp))

            Button(
                onClick = onStartAssist,
                enabled = selectedStyle != null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = MaterialTheme.shapes.large
            ) {
                Icon(
                    imageVector = Icons.Default.CenterFocusStrong,
                    contentDescription = null
                )
                Spacer(Modifier.padding(horizontal = 4.dp))
                Text("アシスト開始")
            }
        }
    }
}

@Composable
private fun DataStatusSection(
    courseStatus: ContentStatus,
    styleStatuses: List<StyleContentStatus>,
    onOpenDetails: () -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "攻略データ",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )

            OutlinedButton(
                onClick = onOpenDetails,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text("詳細")
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.large
        ) {
            Column(
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                StatusRow(
                    label = "コース情報",
                    status = courseStatus
                )

                styleStatuses.forEach { item ->
                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    StatusRow(
                        label = item.runningStyle.label,
                        status = item.status
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusRow(
    label: String,
    status: ContentStatus
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(44.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            modifier = Modifier.weight(1f)
        )
        StatusIcon(status)
        Spacer(Modifier.padding(horizontal = 3.dp))
        Text(
            text = statusLabel(status),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun StatusIcon(status: ContentStatus) {
    when (status) {
        ContentStatus.LATEST -> Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary
        )

        ContentStatus.WAITING_ARTICLE -> Icon(
            imageVector = Icons.Default.Schedule,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )

        ContentStatus.UPDATE_AVAILABLE,
        ContentStatus.ERROR -> Icon(
            imageVector = Icons.Default.Schedule,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.error
        )
    }
}

private fun statusLabel(status: ContentStatus): String =
    when (status) {
        ContentStatus.LATEST -> "最新"
        ContentStatus.UPDATE_AVAILABLE -> "更新あり"
        ContentStatus.WAITING_ARTICLE -> "記事待ち"
        ContentStatus.ERROR -> "取得失敗"
    }

@Composable
private fun HomeBottomNavigation(
    onNavigate: (AppDestination) -> Unit
) {
    NavigationBar {
        NavigationBarItem(
            selected = true,
            onClick = {},
            icon = {
                Icon(Icons.Default.Home, contentDescription = null)
            },
            label = { Text("ホーム") }
        )

        NavigationBarItem(
            selected = false,
            onClick = { onNavigate(AppDestination.SKILLS) },
            icon = {
                Icon(Icons.Default.Search, contentDescription = null)
            },
            label = { Text("スキル") }
        )

        NavigationBarItem(
            selected = false,
            onClick = { onNavigate(AppDestination.ASSIST) },
            icon = {
                Icon(Icons.Default.CenterFocusStrong, contentDescription = null)
            },
            label = { Text("アシスト") }
        )

        NavigationBarItem(
            selected = false,
            onClick = { onNavigate(AppDestination.SETTINGS) },
            icon = {
                Icon(Icons.Default.Settings, contentDescription = null)
            },
            label = { Text("設定") }
        )
    }
}

@Preview(
    showBackground = true,
    widthDp = 393,
    heightDp = 852
)
@Composable
private fun HomeScreenPreview() {
    val previewState = HomeUiState(
        meeting = ChampionsMeeting(
            title = "10月チャンピオンズミーティング",
            venue = "東京",
            surface = "芝",
            distance = 2000,
            direction = "左回り",
            season = "秋",
            weather = "晴",
            groundCondition = "良",
            updatedAt = "2026-10-18T21:30:00+09:00",
            sourceName = "ウマ娘ラボ",
            isSample = true
        ),
        selectedStyle = RunningStyle.SASHI,
        styleSummary = StyleSummary(
            runningStyle = RunningStyle.SASHI,
            targetStats = TargetStats(
                speed = "2000+",
                stamina = "1200+",
                power = "1600+",
                guts = "1100+",
                wisdom = "1400+"
            )
        ),
        courseStatus = ContentStatus.LATEST,
        styleStatuses = listOf(
            StyleContentStatus(RunningStyle.NIGE, ContentStatus.LATEST),
            StyleContentStatus(RunningStyle.SENKO, ContentStatus.LATEST),
            StyleContentStatus(RunningStyle.SASHI, ContentStatus.LATEST),
            StyleContentStatus(RunningStyle.OIKOMI, ContentStatus.WAITING_ARTICLE)
        )
    )

    ChampionsAssistTheme(dynamicColor = false) {
        HomeScreen(
            state = previewState,
            updateState = RemoteUpdateUiState(
                status = RemoteUpdateUiStatus.LATEST,
                message = "攻略データは最新です。",
                canRetry = true
            ),
            onRefresh = {},
            onStyleSelected = {},
            onOpenStyleGuide = {},
            onStartAssist = {},
            onOpenSettings = {},
            onOpenSource = {},
            onOpenDataDetails = {},
            onNavigate = {}
        )
    }
}

