package jp.nekoyuki.championsassist.ui

enum class AppDestination {
    HOME,
    SKILLS,
    ASSIST,
    SETTINGS
}
