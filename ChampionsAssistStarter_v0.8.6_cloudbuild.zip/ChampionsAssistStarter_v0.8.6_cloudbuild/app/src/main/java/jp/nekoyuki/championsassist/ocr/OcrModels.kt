package jp.nekoyuki.championsassist.ocr

data class OcrLine(
    val text: String,
    val left: Int?,
    val top: Int?,
    val right: Int?,
    val bottom: Int?
)

data class OcrResult(
    val rawText: String,
    val lines: List<OcrLine>,
    val imageWidth: Int,
    val imageHeight: Int
)
