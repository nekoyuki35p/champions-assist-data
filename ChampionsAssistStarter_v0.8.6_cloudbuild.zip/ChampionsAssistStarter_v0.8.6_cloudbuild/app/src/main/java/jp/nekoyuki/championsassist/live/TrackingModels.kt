package jp.nekoyuki.championsassist.live

data class TrackingFrame(
    val sourceWidth: Int,
    val sourceHeight: Int,
    val roiTop: Int,
    val roiBottom: Int,
    val signatures: List<FloatArray>
)

data class MotionEstimate(
    val dy: Float,
    val confidence: Float,
    val sceneChanged: Boolean,
    val validBands: Int,
    val correlation: Float
)

enum class ScrollState {
    STOPPED,
    SCROLLING,
    LOST
}

data class TrackedSkillLabel(
    val trackId: Long,
    val skillId: String,
    val skillName: String,
    var grade: String,
    var left: Float,
    var top: Float,
    var right: Float,
    var bottom: Float,
    var targetLeft: Float? = null,
    var targetTop: Float? = null,
    var targetRight: Float? = null,
    var targetBottom: Float? = null,
    var lastOcrConfirmedAt: Long,
    var lastTrackedAt: Long,
    var trackingConfidence: Float = 1.0f,
    var ocrConfidence: Float = 1.0f,
    var missedOcrCount: Int = 0,
    var visible: Boolean = true
) {
    fun centerY(): Float =
        (top + bottom) / 2f
}
