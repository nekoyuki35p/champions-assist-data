package jp.nekoyuki.championsassist.data.model

data class ChampionsMeetingData(
    val schemaVersion: String,
    val dataVersion: String,
    val meeting: MeetingData,
    val course: CourseData,
    val runningStyles: Map<String, RunningStyleData>,
    val sources: List<SourceData>,
    val metadata: MetadataData
)

data class MeetingData(
    val id: String,
    val title: String,
    val shortTitle: String?,
    val year: Int,
    val month: Int,
    val status: String,
    val startDate: String?,
    val endDate: String?
)

data class CourseData(
    val venue: String,
    val surface: String,
    val distance: Int,
    val distanceCategory: String,
    val direction: String,
    val season: String,
    val weather: String?,
    val groundCondition: String?,
    val courseTags: List<String>
)

data class RunningStyleData(
    val displayName: String,
    val contentStatus: String,
    val targetStats: TargetStatsData,
    val recommendedAptitudes: List<RecommendedAptitudeData>,
    val skills: List<SkillData>,
    val notes: List<NoteData>,
    val sourceIds: List<String>,
    val updatedAt: String?
)

data class TargetStatsData(
    val speed: StatTargetData?,
    val stamina: StatTargetData?,
    val power: StatTargetData?,
    val guts: StatTargetData?,
    val wisdom: StatTargetData?
)

data class StatTargetData(
    val value: Int?,
    val operator: String?,
    val display: String?
)

data class RecommendedAptitudeData(
    val type: String,
    val target: String,
    val recommendedRank: String?,
    val priority: String?,
    val note: String?
)

data class SkillData(
    val id: String,
    val name: String,
    val aliases: List<String>,
    val category: String,
    val grade: String,
    val effectiveness: String?,
    val priority: Int?,
    val isRecommended: Boolean,
    val reason: String?,
    val conditions: List<String>,
    val sourceIds: List<String>
)

data class NoteData(
    val type: String,
    val text: String
)

data class SourceData(
    val id: String,
    val siteName: String,
    val title: String,
    val url: String,
    val articleType: String,
    val runningStyle: String?,
    val publishedAt: String?,
    val checkedAt: String?
)

data class MetadataData(
    val generatedAt: String?,
    val generator: String?,
    val sourceSite: String?,
    val isComplete: Boolean,
    val isSample: Boolean,
    val availableStyles: List<String>,
    val waitingStyles: List<String>
)
