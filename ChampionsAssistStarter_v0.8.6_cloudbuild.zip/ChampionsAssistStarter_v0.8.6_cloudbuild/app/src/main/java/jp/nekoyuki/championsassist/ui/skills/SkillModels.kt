package jp.nekoyuki.championsassist.ui.skills

import jp.nekoyuki.championsassist.data.model.ChampionsMeetingData
import jp.nekoyuki.championsassist.data.model.SkillData
import jp.nekoyuki.championsassist.ui.home.RunningStyle

enum class SkillGradeFilter(val label: String) {
    ALL("すべて"),
    S("S"),
    A("A"),
    B("B")
}

enum class SkillCategoryFilter(
    val key: String?,
    val label: String
) {
    ALL(null, "すべて"),
    ACCELERATION("acceleration", "加速"),
    SPEED("speed", "速度"),
    RECOVERY("recovery", "回復"),
    POSITIONING("positioning", "位置取り"),
    GREEN("green", "緑"),
    INHERITED_UNIQUE("inherited_unique", "継承固有"),
    DEBUFF("debuff", "デバフ"),
    OTHER("other", "その他")
}

data class SkillListItemUi(
    val id: String,
    val name: String,
    val grade: String,
    val categoryKey: String,
    val categoryLabel: String,
    val effectiveness: String?,
    val reason: String?,
    val conditions: List<String>,
    val aliases: List<String>,
    val isRecommended: Boolean,
    val priority: Int
)

data class SkillScreenUiState(
    val meetingTitle: String,
    val runningStyle: RunningStyle,
    val contentStatus: String,
    val skills: List<SkillListItemUi>,
    val isSample: Boolean
)

fun ChampionsMeetingData.toSkillScreenUiState(
    style: RunningStyle
): SkillScreenUiState {
    val styleData = runningStyles[style.key]

    val items = styleData?.skills
        .orEmpty()
        .map { it.toUi() }
        .sortedWith(
            compareByDescending<SkillListItemUi> { gradeRank(it.grade) }
                .thenByDescending { it.priority }
                .thenBy { it.name }
        )

    return SkillScreenUiState(
        meetingTitle = meeting.title,
        runningStyle = style,
        contentStatus = styleData?.contentStatus ?: "error",
        skills = items,
        isSample = metadata.isSample
    )
}

private fun SkillData.toUi(): SkillListItemUi =
    SkillListItemUi(
        id = id,
        name = name,
        grade = grade,
        categoryKey = category,
        categoryLabel = categoryLabel(category),
        effectiveness = effectiveness,
        reason = reason,
        conditions = conditions,
        aliases = aliases,
        isRecommended = isRecommended,
        priority = priority ?: gradeRank(grade)
    )

private fun gradeRank(grade: String): Int =
    when (grade.uppercase()) {
        "S" -> 100
        "A" -> 70
        "B" -> 40
        "C" -> 20
        else -> 0
    }

fun categoryLabel(category: String): String =
    when (category) {
        "acceleration" -> "加速"
        "speed" -> "速度"
        "recovery" -> "回復"
        "positioning" -> "位置取り"
        "green" -> "緑"
        "inherited_unique" -> "継承固有"
        "debuff" -> "デバフ"
        else -> "その他"
    }
