package jp.nekoyuki.championsassist.data.update

import jp.nekoyuki.championsassist.data.model.ChampionsMeetingData

data class RemoteUpdateConfig(
    val latestJsonUrl: String,
    val autoRefreshOnLaunch: Boolean,
    val connectTimeoutMs: Int,
    val readTimeoutMs: Int,
    val maxPayloadBytes: Int
)

enum class DataOrigin {
    CACHE,
    ASSET
}

data class LoadedMeetingData(
    val data: ChampionsMeetingData,
    val origin: DataOrigin
)

sealed interface RemoteUpdateResult {
    data class Updated(
        val data: ChampionsMeetingData,
        val dataVersion: String
    ) : RemoteUpdateResult

    data class Latest(
        val dataVersion: String
    ) : RemoteUpdateResult

    data object NotModified : RemoteUpdateResult

    data object Disabled : RemoteUpdateResult

    data class Failed(
        val message: String
    ) : RemoteUpdateResult
}
