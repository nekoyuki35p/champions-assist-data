package jp.nekoyuki.championsassist.ui.skills

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import jp.nekoyuki.championsassist.ui.AppDestination
import jp.nekoyuki.championsassist.ui.home.RunningStyle
import jp.nekoyuki.championsassist.ui.theme.ChampionsAssistTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SkillScreen(
    state: SkillScreenUiState,
    onStyleSelected: (RunningStyle) -> Unit,
    onBack: () -> Unit,
    onNavigate: (AppDestination) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var gradeFilterName by rememberSaveable {
        mutableStateOf(SkillGradeFilter.ALL.name)
    }
    var categoryFilterName by rememberSaveable {
        mutableStateOf(SkillCategoryFilter.ALL.name)
    }

    val gradeFilter = runCatching {
        SkillGradeFilter.valueOf(gradeFilterName)
    }.getOrDefault(SkillGradeFilter.ALL)

    val categoryFilter = runCatching {
        SkillCategoryFilter.valueOf(categoryFilterName)
    }.getOrDefault(SkillCategoryFilter.ALL)

    val filteredSkills = state.skills.filter { skill ->
        val matchesQuery =
            query.isBlank() ||
                skill.name.contains(query, ignoreCase = true) ||
                skill.aliases.any { it.contains(query, ignoreCase = true) }

        val matchesGrade =
            gradeFilter == SkillGradeFilter.ALL ||
                skill.grade.equals(gradeFilter.label, ignoreCase = true)

        val matchesCategory =
            categoryFilter.key == null ||
                skill.categoryKey == categoryFilter.key

        matchesQuery && matchesGrade && matchesCategory
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "有効スキル",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${state.meetingTitle} / ${state.runningStyle.label}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "戻る"
                        )
                    }
                }
            )
        },
        bottomBar = {
            SkillBottomNavigation(
                onNavigate = onNavigate
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 12.dp,
                bottom = 24.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                RunningStyleSelector(
                    selectedStyle = state.runningStyle,
                    onStyleSelected = onStyleSelected
                )
            }

            if (state.isSample) {
                item {
                    SampleDataBanner()
                }
            }

            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null
                        )
                    },
                    label = { Text("スキル名を検索") },
                    placeholder = { Text("例：王手") }
                )
            }

            item {
                Text(
                    text = "評価",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(SkillGradeFilter.entries) { filter ->
                        FilterChip(
                            selected = filter == gradeFilter,
                            onClick = {
                                gradeFilterName = filter.name
                            },
                            label = {
                                Text(filter.label)
                            }
                        )
                    }
                }
            }

            item {
                Text(
                    text = "カテゴリ",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(SkillCategoryFilter.entries) { filter ->
                        FilterChip(
                            selected = filter == categoryFilter,
                            onClick = {
                                categoryFilterName = filter.name
                            },
                            label = {
                                Text(filter.label)
                            }
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${state.runningStyle.label}の有効スキル",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )

                    Text(
                        text = "${filteredSkills.size}件",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (state.contentStatus == "waiting_article") {
                item {
                    EmptyMessageCard(
                        title = "攻略記事待ち",
                        message = "この脚質の詳細記事がまだ登録されていません。"
                    )
                }
            } else if (filteredSkills.isEmpty()) {
                item {
                    EmptyMessageCard(
                        title = "該当スキルなし",
                        message = if (state.skills.isEmpty()) {
                            "この脚質のスキルデータはまだ登録されていません。"
                        } else {
                            "検索条件または絞り込み条件を変更してください。"
                        }
                    )
                }
            } else {
                itemsIndexed(
                    items = filteredSkills,
                    key = { _, item -> item.id }
                ) { index, skill ->
                    SkillCard(skill)

                    if (index != filteredSkills.lastIndex) {
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RunningStyleSelector(
    selectedStyle: RunningStyle,
    onStyleSelected: (RunningStyle) -> Unit
) {
    Column {
        Text(
            text = "脚質",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            RunningStyle.entries.forEach { style ->
                FilterChip(
                    selected = style == selectedStyle,
                    onClick = { onStyleSelected(style) },
                    modifier = Modifier.weight(1f),
                    label = {
                        Text(style.label)
                    }
                )
            }
        }
    }
}

@Composable
private fun SkillCard(
    skill: SkillListItemUi
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                GradeBadge(skill.grade)

                Spacer(Modifier.padding(horizontal = 5.dp))

                Text(
                    text = skill.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )

                AssistChip(
                    onClick = {},
                    label = {
                        Text(skill.categoryLabel)
                    }
                )
            }

            skill.reason?.takeIf { it.isNotBlank() }?.let {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            if (skill.conditions.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "条件：${skill.conditions.joinToString(" / ")}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            skill.effectiveness?.let {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "判定：${effectivenessLabel(it)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun GradeBadge(
    grade: String
) {
    val container = when (grade.uppercase()) {
        "S" -> MaterialTheme.colorScheme.primaryContainer
        "A" -> MaterialTheme.colorScheme.secondaryContainer
        "B" -> MaterialTheme.colorScheme.tertiaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }

    Surface(
        color = container,
        shape = MaterialTheme.shapes.medium
    ) {
        Text(
            text = grade.uppercase(),
            modifier = Modifier.padding(
                horizontal = 11.dp,
                vertical = 6.dp
            ),
            fontWeight = FontWeight.ExtraBold
        )
    }
}

@Composable
private fun SampleDataBanner() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.errorContainer,
        shape = MaterialTheme.shapes.large
    ) {
        Text(
            text = "現在はUI確認用のサンプル攻略データです。",
            modifier = Modifier.padding(12.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onErrorContainer
        )
    }
}

@Composable
private fun EmptyMessageCard(
    title: String,
    message: String
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

private fun effectivenessLabel(value: String): String =
    when (value) {
        "effective" -> "有効"
        "conditional" -> "条件付き"
        "low_value" -> "優先度低め"
        "ineffective" -> "非推奨"
        else -> "未評価"
    }

@Composable
private fun SkillBottomNavigation(
    onNavigate: (AppDestination) -> Unit
) {
    NavigationBar {
        NavigationBarItem(
            selected = false,
            onClick = { onNavigate(AppDestination.HOME) },
            icon = {
                Icon(Icons.Default.Home, contentDescription = null)
            },
            label = { Text("ホーム") }
        )

        NavigationBarItem(
            selected = true,
            onClick = {},
            icon = {
                Icon(Icons.Default.Search, contentDescription = null)
            },
            label = { Text("スキル") }
        )

        NavigationBarItem(
            selected = false,
            onClick = { onNavigate(AppDestination.ASSIST) },
            icon = {
                Icon(Icons.Default.CenterFocusStrong, contentDescription = null)
            },
            label = { Text("アシスト") }
        )

        NavigationBarItem(
            selected = false,
            onClick = { onNavigate(AppDestination.SETTINGS) },
            icon = {
                Icon(Icons.Default.Settings, contentDescription = null)
            },
            label = { Text("設定") }
        )
    }
}

@Preview(
    showBackground = true,
    widthDp = 393,
    heightDp = 852
)
@Composable
private fun SkillScreenPreview() {
    ChampionsAssistTheme(dynamicColor = false) {
        SkillScreen(
            state = SkillScreenUiState(
                meetingTitle = "10月チャンピオンズミーティング",
                runningStyle = RunningStyle.SASHI,
                contentStatus = "ready",
                isSample = true,
                skills = listOf(
                    SkillListItemUi(
                        id = "sample_1",
                        name = "サンプル加速スキル",
                        grade = "S",
                        categoryKey = "acceleration",
                        categoryLabel = "加速",
                        effectiveness = "effective",
                        reason = "今回のコースで有効な加速スキルという想定のサンプル。",
                        conditions = listOf("差し"),
                        aliases = emptyList(),
                        isRecommended = true,
                        priority = 100
                    ),
                    SkillListItemUi(
                        id = "sample_2",
                        name = "サンプル速度スキル",
                        grade = "A",
                        categoryKey = "speed",
                        categoryLabel = "速度",
                        effectiveness = "effective",
                        reason = "中盤速度スキルの表示確認用。",
                        conditions = listOf("差し"),
                        aliases = emptyList(),
                        isRecommended = true,
                        priority = 70
                    )
                )
            ),
            onStyleSelected = {},
            onBack = {},
            onNavigate = {}
        )
    }
}
