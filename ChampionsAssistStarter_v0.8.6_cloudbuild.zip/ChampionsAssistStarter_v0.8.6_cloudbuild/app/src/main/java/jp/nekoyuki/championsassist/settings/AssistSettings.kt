package jp.nekoyuki.championsassist.settings

import android.content.Context

data class AssistSettings(
    val showGradeS: Boolean = true,
    val showGradeA: Boolean = true,
    val showGradeB: Boolean = true,
    val minConfidence: Float = 0.82f,
    val scanIntervalMs: Long = 350L,
    val overlayOffsetX: Int = 0,
    val overlayOffsetY: Int = 0,
    val overlayLabelScale: Float = 1.0f,
    val showBoundingBoxes: Boolean = true
) {
    fun shouldShowGrade(
        grade: String
    ): Boolean =
        when (
            grade.uppercase()
        ) {
            "S" -> showGradeS
            "A" -> showGradeA
            "B" -> showGradeB
            else -> false
        }
}

class AssistSettingsStore(
    context: Context
) {
    private val preferences =
        context.getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        )

    init {
        migrateForFastTracking()
    }

    fun load(): AssistSettings =
        AssistSettings(
            showGradeS =
                preferences.getBoolean(
                    KEY_SHOW_S,
                    true
                ),
            showGradeA =
                preferences.getBoolean(
                    KEY_SHOW_A,
                    true
                ),
            showGradeB =
                preferences.getBoolean(
                    KEY_SHOW_B,
                    true
                ),
            minConfidence =
                preferences.getFloat(
                    KEY_MIN_CONFIDENCE,
                    0.82f
                ),
            scanIntervalMs =
                preferences.getLong(
                    KEY_SCAN_INTERVAL,
                    DEFAULT_SCAN_INTERVAL_MS
                ),
            overlayOffsetX =
                preferences.getInt(
                    KEY_OFFSET_X,
                    0
                ),
            overlayOffsetY =
                preferences.getInt(
                    KEY_OFFSET_Y,
                    0
                ),
            overlayLabelScale =
                preferences.getFloat(
                    KEY_LABEL_SCALE,
                    1.0f
                ),
            showBoundingBoxes =
                preferences.getBoolean(
                    KEY_SHOW_BOXES,
                    true
                )
        )

    fun save(
        settings: AssistSettings
    ) {
        preferences.edit()
            .putBoolean(
                KEY_SHOW_S,
                settings.showGradeS
            )
            .putBoolean(
                KEY_SHOW_A,
                settings.showGradeA
            )
            .putBoolean(
                KEY_SHOW_B,
                settings.showGradeB
            )
            .putFloat(
                KEY_MIN_CONFIDENCE,
                settings.minConfidence
            )
            .putLong(
                KEY_SCAN_INTERVAL,
                settings
                    .scanIntervalMs
                    .coerceIn(
                        MIN_SCAN_INTERVAL_MS,
                        MAX_SCAN_INTERVAL_MS
                    )
            )
            .putInt(
                KEY_OFFSET_X,
                settings.overlayOffsetX
            )
            .putInt(
                KEY_OFFSET_Y,
                settings.overlayOffsetY
            )
            .putFloat(
                KEY_LABEL_SCALE,
                settings.overlayLabelScale
            )
            .putBoolean(
                KEY_SHOW_BOXES,
                settings.showBoundingBoxes
            )
            .putInt(
                KEY_SETTINGS_VERSION,
                SETTINGS_VERSION
            )
            .apply()
    }

    fun reset(): AssistSettings {
        val defaults =
            AssistSettings()

        save(defaults)

        return defaults
    }

    private fun migrateForFastTracking() {
        val version =
            preferences.getInt(
                KEY_SETTINGS_VERSION,
                1
            )

        if (
            version >=
            SETTINGS_VERSION
        ) {
            return
        }

        val oldInterval =
            preferences.getLong(
                KEY_SCAN_INTERVAL,
                1400L
            )

        val editor =
            preferences.edit()

        /*
         * v0.8.4 default was 1400 ms. If the user was still on that old
         * default, migrate to the new fast-tracking default automatically.
         * Custom values are preserved.
         */
        if (
            !preferences.contains(
                KEY_SCAN_INTERVAL
            ) ||
            oldInterval == 1400L
        ) {
            editor.putLong(
                KEY_SCAN_INTERVAL,
                DEFAULT_SCAN_INTERVAL_MS
            )
        }

        editor
            .putInt(
                KEY_SETTINGS_VERSION,
                SETTINGS_VERSION
            )
            .apply()
    }

    companion object {
        const val DEFAULT_SCAN_INTERVAL_MS =
            350L

        const val MIN_SCAN_INTERVAL_MS =
            250L

        const val MAX_SCAN_INTERVAL_MS =
            2000L

        private const val PREFS_NAME =
            "assist_settings"

        private const val KEY_SHOW_S =
            "show_grade_s"

        private const val KEY_SHOW_A =
            "show_grade_a"

        private const val KEY_SHOW_B =
            "show_grade_b"

        private const val KEY_MIN_CONFIDENCE =
            "min_confidence"

        private const val KEY_SCAN_INTERVAL =
            "scan_interval_ms"

        private const val KEY_OFFSET_X =
            "overlay_offset_x"

        private const val KEY_OFFSET_Y =
            "overlay_offset_y"

        private const val KEY_LABEL_SCALE =
            "overlay_label_scale"

        private const val KEY_SHOW_BOXES =
            "show_bounding_boxes"

        private const val KEY_SETTINGS_VERSION =
            "settings_version"

        private const val SETTINGS_VERSION =
            2
    }
}
