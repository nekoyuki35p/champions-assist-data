package jp.nekoyuki.championsassist.live

import jp.nekoyuki.championsassist.ocr.SkillOcrMatch
import kotlin.math.abs
import kotlin.math.max

class TrackedLabelStore {

    private val labels =
        mutableListOf<
            TrackedSkillLabel
        >()

    private var nextTrackId =
        1L

    @Synchronized
    fun clear() {
        labels.clear()
    }

    @Synchronized
    fun count(): Int =
        labels.size

    @Synchronized
    fun snapshot():
        List<TrackedSkillLabel> =
        labels.map {
            it.copy()
        }

    @Synchronized
    fun applyMotion(
        dy: Float,
        confidence: Float,
        now: Long
    ) {
        if (
            abs(dy) >
            MAX_APPLIED_DY_PX
        ) {
            markTrackingMiss()
            return
        }

        labels.forEach {
            label ->

            label.top +=
                dy

            label.bottom +=
                dy

            label.targetTop =
                label
                    .targetTop
                    ?.plus(
                        dy
                    )

            label.targetBottom =
                label
                    .targetBottom
                    ?.plus(
                        dy
                    )

            label.lastTrackedAt =
                now

            label.trackingConfidence =
                (
                    label
                        .trackingConfidence *
                    0.72f
                ) +
                (
                    confidence *
                    0.28f
                )
        }
    }

    @Synchronized
    fun markTrackingMiss() {
        labels.forEach {
            it.trackingConfidence *=
                0.82f
        }
    }

    @Synchronized
    fun applyCorrections() {
        labels.forEach {
            label ->

            val targetLeft =
                label.targetLeft

            val targetTop =
                label.targetTop

            val targetRight =
                label.targetRight

            val targetBottom =
                label.targetBottom

            if (
                targetLeft == null ||
                targetTop == null ||
                targetRight == null ||
                targetBottom == null
            ) {
                return@forEach
            }

            val error =
                targetTop -
                label.top

            if (
                abs(error) <
                1.5f
            ) {
                label.left =
                    targetLeft

                label.top =
                    targetTop

                label.right =
                    targetRight

                label.bottom =
                    targetBottom

                clearTargets(
                    label
                )
            } else {
                label.left +=
                    (
                        targetLeft -
                        label.left
                    ) *
                    CORRECTION_LERP

                label.top +=
                    (
                        targetTop -
                        label.top
                    ) *
                    CORRECTION_LERP

                label.right +=
                    (
                        targetRight -
                        label.right
                    ) *
                    CORRECTION_LERP

                label.bottom +=
                    (
                        targetBottom -
                        label.bottom
                    ) *
                    CORRECTION_LERP
            }
        }
    }

    @Synchronized
    fun reconcile(
        matches:
            List<SkillOcrMatch>,
        now: Long,
        scrollState:
            ScrollState
    ) {
        val matchedTrackIds =
            mutableSetOf<Long>()

        matches.forEach {
            match ->

            val left =
                match.left
                    ?.toFloat()
                    ?: return@forEach

            val top =
                match.top
                    ?.toFloat()
                    ?: return@forEach

            val right =
                match.right
                    ?.toFloat()
                    ?: return@forEach

            val bottom =
                match.bottom
                    ?.toFloat()
                    ?: return@forEach

            val center =
                (
                    top +
                    bottom
                ) /
                2f

            val existing =
                labels
                    .asSequence()
                    .filter {
                        it.skillId ==
                        match.skillId
                    }
                    .filter {
                        abs(
                            it.centerY() -
                            center
                        ) <=
                        SAME_LABEL_MAX_DISTANCE_PX
                    }
                    .minByOrNull {
                        abs(
                            it.centerY() -
                            center
                        )
                    }

            if (
                existing == null
            ) {
                val created =
                    TrackedSkillLabel(
                        trackId =
                            nextTrackId++,
                        skillId =
                            match.skillId,
                        skillName =
                            match.skillName,
                        grade =
                            match.grade,
                        left =
                            left,
                        top =
                            top,
                        right =
                            right,
                        bottom =
                            bottom,
                        lastOcrConfirmedAt =
                            now,
                        lastTrackedAt =
                            now,
                        trackingConfidence =
                            1.0f,
                        ocrConfidence =
                            match.confidence
                    )

                labels +=
                    created

                matchedTrackIds +=
                    created.trackId

                return@forEach
            }

            matchedTrackIds +=
                existing.trackId

            existing.grade =
                match.grade

            existing.lastOcrConfirmedAt =
                now

            existing.ocrConfidence =
                match.confidence

            existing.missedOcrCount =
                0

            existing.trackingConfidence =
                max(
                    existing
                        .trackingConfidence,
                    0.70f
                )

            val error =
                center -
                existing.centerY()

            if (
                abs(error) >=
                HARD_RELOCK_PX
            ) {
                existing.left =
                    left
                existing.top =
                    top
                existing.right =
                    right
                existing.bottom =
                    bottom

                clearTargets(
                    existing
                )
            } else {
                existing.targetLeft =
                    left
                existing.targetTop =
                    top
                existing.targetRight =
                    right
                existing.targetBottom =
                    bottom
            }
        }

        val allowedMisses =
            if (
                scrollState ==
                ScrollState.SCROLLING
            ) {
                3
            } else {
                2
            }

        labels.forEach {
            label ->
            if (
                label.trackId !in
                matchedTrackIds
            ) {
                label.missedOcrCount++
            }
        }

        labels.removeAll {
            it.missedOcrCount >=
            allowedMisses
        }
    }

    @Synchronized
    fun purge(
        screenHeight: Int,
        scrollState: ScrollState,
        now: Long
    ) {
        labels.removeAll {
            label ->

            val outside =
                label.bottom <
                -OUTSIDE_MARGIN_PX ||
                label.top >
                screenHeight +
                OUTSIDE_MARGIN_PX

            val age =
                now -
                label
                    .lastOcrConfirmedAt

            val stale =
                when (
                    scrollState
                ) {
                    ScrollState.SCROLLING ->
                        age >
                        STALE_SCROLLING_MS

                    ScrollState.STOPPED ->
                        age >
                        STALE_STOPPED_MS

                    ScrollState.LOST ->
                        true
                }

            outside ||
            stale ||
            label.trackingConfidence <
            MIN_LABEL_CONFIDENCE
        }
    }

    private fun clearTargets(
        label:
            TrackedSkillLabel
    ) {
        label.targetLeft =
            null

        label.targetTop =
            null

        label.targetRight =
            null

        label.targetBottom =
            null
    }

    private companion object {
        const val SAME_LABEL_MAX_DISTANCE_PX =
            150f

        const val HARD_RELOCK_PX =
            85f

        const val CORRECTION_LERP =
            0.32f

        const val MAX_APPLIED_DY_PX =
            700f

        const val OUTSIDE_MARGIN_PX =
            90f

        const val STALE_SCROLLING_MS =
            1500L

        const val STALE_STOPPED_MS =
            3200L

        const val MIN_LABEL_CONFIDENCE =
            0.12f
    }
}
