package jp.nekoyuki.championsassist.data.repository

import android.content.Context
import jp.nekoyuki.championsassist.data.model.ChampionsMeetingData
import jp.nekoyuki.championsassist.data.model.CourseData
import jp.nekoyuki.championsassist.data.model.MeetingData
import jp.nekoyuki.championsassist.data.model.MetadataData
import jp.nekoyuki.championsassist.data.model.NoteData
import jp.nekoyuki.championsassist.data.model.RecommendedAptitudeData
import jp.nekoyuki.championsassist.data.model.RunningStyleData
import jp.nekoyuki.championsassist.data.model.SkillData
import jp.nekoyuki.championsassist.data.model.SourceData
import jp.nekoyuki.championsassist.data.model.StatTargetData
import jp.nekoyuki.championsassist.data.model.TargetStatsData
import jp.nekoyuki.championsassist.data.update.DataOrigin
import jp.nekoyuki.championsassist.data.update.LoadedMeetingData
import jp.nekoyuki.championsassist.data.update.RemoteUpdateConfig
import jp.nekoyuki.championsassist.data.update.RemoteUpdateResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class ChampionsMeetingRepository(
    private val context: Context
) {
    private val cacheDirectory = File(
        context.filesDir,
        CACHE_DIRECTORY_NAME
    )

    private val cacheFile = File(
        cacheDirectory,
        CACHE_FILE_NAME
    )

    private val metadataPreferences = context.getSharedPreferences(
        UPDATE_PREFS_NAME,
        Context.MODE_PRIVATE
    )

    suspend fun loadInitialData(): LoadedMeetingData =
        withContext(Dispatchers.IO) {
            loadFromCacheOrNull()?.let {
                return@withContext LoadedMeetingData(
                    data = it,
                    origin = DataOrigin.CACHE
                )
            }

            LoadedMeetingData(
                data = loadFromAssets(),
                origin = DataOrigin.ASSET
            )
        }

    fun loadRemoteConfig(
        fileName: String = REMOTE_CONFIG_ASSET
    ): RemoteUpdateConfig {
        val jsonText = context.assets
            .open(fileName)
            .bufferedReader()
            .use { it.readText() }

        val json = JSONObject(jsonText)

        return RemoteUpdateConfig(
            latestJsonUrl = json.optString(
                "latestJsonUrl",
                ""
            ).trim(),
            autoRefreshOnLaunch = json.optBoolean(
                "autoRefreshOnLaunch",
                true
            ),
            connectTimeoutMs = json.optInt(
                "connectTimeoutMs",
                DEFAULT_CONNECT_TIMEOUT_MS
            ),
            readTimeoutMs = json.optInt(
                "readTimeoutMs",
                DEFAULT_READ_TIMEOUT_MS
            ),
            maxPayloadBytes = json.optInt(
                "maxPayloadBytes",
                DEFAULT_MAX_PAYLOAD_BYTES
            ).coerceAtLeast(64 * 1024)
        )
    }

    suspend fun refreshFromRemote(
        config: RemoteUpdateConfig
    ): RemoteUpdateResult =
        withContext(Dispatchers.IO) {
            if (config.latestJsonUrl.isBlank()) {
                return@withContext RemoteUpdateResult.Disabled
            }

            val url = runCatching {
                URL(config.latestJsonUrl)
            }.getOrElse {
                return@withContext RemoteUpdateResult.Failed(
                    "latest.jsonのURLが正しくありません。"
                )
            }

            if (url.protocol.lowercase() != "https") {
                return@withContext RemoteUpdateResult.Failed(
                    "更新URLはHTTPSのみ利用できます。"
                )
            }

            val connection = runCatching {
                url.openConnection() as HttpURLConnection
            }.getOrElse {
                return@withContext RemoteUpdateResult.Failed(
                    "更新サーバーへ接続できませんでした。"
                )
            }

            try {
                connection.requestMethod = "GET"
                connection.connectTimeout = config.connectTimeoutMs
                connection.readTimeout = config.readTimeoutMs
                connection.instanceFollowRedirects = true
                connection.setRequestProperty(
                    "Accept",
                    "application/json"
                )
                connection.setRequestProperty(
                    "User-Agent",
                    "ChampionsAssist-Android/0.5"
                )

                val savedSourceUrl = metadataPreferences
                    .getString(KEY_SOURCE_URL, null)

                if (
                    cacheFile.isFile &&
                    savedSourceUrl == config.latestJsonUrl
                ) {
                    metadataPreferences
                        .getString(KEY_ETAG, null)
                        ?.takeIf { it.isNotBlank() }
                        ?.let {
                            connection.setRequestProperty(
                                "If-None-Match",
                                it
                            )
                        }

                    metadataPreferences
                        .getString(KEY_LAST_MODIFIED, null)
                        ?.takeIf { it.isNotBlank() }
                        ?.let {
                            connection.setRequestProperty(
                                "If-Modified-Since",
                                it
                            )
                        }
                }

                val responseCode = connection.responseCode

                if (connection.url.protocol.lowercase() != "https") {
                    return@withContext RemoteUpdateResult.Failed(
                        "更新先がHTTPS以外へリダイレクトされました。"
                    )
                }

                when (responseCode) {
                    HttpURLConnection.HTTP_NOT_MODIFIED -> {
                        saveResponseMetadata(connection)
                        return@withContext RemoteUpdateResult.NotModified
                    }

                    HttpURLConnection.HTTP_OK -> {
                        val remoteText = connection
                            .inputStream
                            .buffered()
                            .use {
                                readUtf8WithLimit(
                                    input = it,
                                    maxBytes = config.maxPayloadBytes
                                )
                            }

                        val remoteData = runCatching {
                            parseAndValidate(remoteText)
                        }.getOrElse { error ->
                            return@withContext RemoteUpdateResult.Failed(
                                "取得したlatest.jsonが無効です: " +
                                    (error.message ?: "解析エラー")
                            )
                        }

                        val currentText = cacheFile
                            .takeIf { it.isFile }
                            ?.readText(Charsets.UTF_8)

                        if (currentText == remoteText) {
                            saveResponseMetadata(connection)
                            return@withContext RemoteUpdateResult.Latest(
                                dataVersion = remoteData.dataVersion
                            )
                        }

                        saveCacheAtomically(remoteText)
                        saveResponseMetadata(connection)

                        return@withContext RemoteUpdateResult.Updated(
                            data = remoteData,
                            dataVersion = remoteData.dataVersion
                        )
                    }

                    else -> {
                        return@withContext RemoteUpdateResult.Failed(
                            "更新サーバー応答: HTTP $responseCode"
                        )
                    }
                }
            } catch (error: IOException) {
                RemoteUpdateResult.Failed(
                    "ネットワーク更新に失敗しました: " +
                        (error.message ?: "通信エラー")
                )
            } catch (error: Exception) {
                RemoteUpdateResult.Failed(
                    "更新処理に失敗しました: " +
                        (error.message ?: "不明なエラー")
                )
            } finally {
                connection.disconnect()
            }
        }

    fun loadFromAssets(
        fileName: String = FALLBACK_ASSET_NAME
    ): ChampionsMeetingData {
        val jsonText = context.assets
            .open(fileName)
            .bufferedReader()
            .use { it.readText() }

        return parseAndValidate(jsonText)
    }

    fun loadFromCacheOrNull(): ChampionsMeetingData? {
        if (!cacheFile.isFile) {
            return null
        }

        return runCatching {
            parseAndValidate(
                cacheFile.readText(Charsets.UTF_8)
            )
        }.getOrElse {
            // 壊れたキャッシュは使わず、次回Assetsへフォールバック。
            cacheFile.delete()
            null
        }
    }

    fun cachePathForDebug(): String =
        cacheFile.absolutePath

    private fun parseAndValidate(
        jsonText: String
    ): ChampionsMeetingData {
        val root = JSONObject(jsonText)
        validateRoot(root)
        return parse(root)
    }

    private fun validateRoot(
        root: JSONObject
    ) {
        val schemaVersion = root.optString(
            "schemaVersion",
            ""
        )

        require(schemaVersion.startsWith("0.1")) {
            "未対応のschemaVersion: $schemaVersion"
        }

        require(root.has("dataVersion")) {
            "dataVersionがありません"
        }

        val styles = root.getJSONObject("runningStyles")
        REQUIRED_STYLE_KEYS.forEach { key ->
            require(styles.has(key)) {
                "runningStyles.$key がありません"
            }
        }

        root.getJSONObject("meeting")
        root.getJSONObject("course")
        root.getJSONObject("metadata")
    }

    private fun saveCacheAtomically(
        jsonText: String
    ) {
        cacheDirectory.mkdirs()

        val tempFile = File(
            cacheDirectory,
            "$CACHE_FILE_NAME.tmp"
        )

        tempFile.outputStream().buffered().use {
            it.write(jsonText.toByteArray(Charsets.UTF_8))
            it.flush()
        }

        if (cacheFile.exists()) {
            cacheFile.delete()
        }

        if (!tempFile.renameTo(cacheFile)) {
            tempFile.copyTo(
                target = cacheFile,
                overwrite = true
            )
            tempFile.delete()
        }
    }

    private fun saveResponseMetadata(
        connection: HttpURLConnection
    ) {
        val etag = connection.getHeaderField("ETag")
        val lastModified = connection.getHeaderField(
            "Last-Modified"
        )

        metadataPreferences.edit()
            .apply {
                if (!etag.isNullOrBlank()) {
                    putString(KEY_ETAG, etag)
                }
                if (!lastModified.isNullOrBlank()) {
                    putString(
                        KEY_LAST_MODIFIED,
                        lastModified
                    )
                }
                putString(
                    KEY_SOURCE_URL,
                    connection.url.toString()
                )
                putLong(
                    KEY_LAST_SUCCESS_EPOCH_MS,
                    System.currentTimeMillis()
                )
            }
            .apply()
    }

    private fun readUtf8WithLimit(
        input: java.io.InputStream,
        maxBytes: Int
    ): String {
        val buffer = ByteArray(8 * 1024)
        val output = java.io.ByteArrayOutputStream()
        var total = 0

        while (true) {
            val count = input.read(buffer)
            if (count < 0) break

            total += count
            if (total > maxBytes) {
                throw IOException(
                    "latest.jsonが上限サイズを超えています。"
                )
            }

            output.write(buffer, 0, count)
        }

        return output.toString(Charsets.UTF_8.name())
    }

    private fun parse(
        root: JSONObject
    ): ChampionsMeetingData {
        val meetingJson = root.getJSONObject("meeting")
        val courseJson = root.getJSONObject("course")
        val stylesJson = root.getJSONObject("runningStyles")
        val metadataJson = root.getJSONObject("metadata")

        val runningStyles = buildMap {
            val keys = stylesJson.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                put(
                    key,
                    parseRunningStyle(
                        stylesJson.getJSONObject(key)
                    )
                )
            }
        }

        return ChampionsMeetingData(
            schemaVersion = root.getString("schemaVersion"),
            dataVersion = root.getString("dataVersion"),
            meeting = MeetingData(
                id = meetingJson.getString("id"),
                title = meetingJson.getString("title"),
                shortTitle = meetingJson.nullableString("shortTitle"),
                year = meetingJson.getInt("year"),
                month = meetingJson.getInt("month"),
                status = meetingJson.getString("status"),
                startDate = meetingJson.nullableString("startDate"),
                endDate = meetingJson.nullableString("endDate")
            ),
            course = CourseData(
                venue = courseJson.getString("venue"),
                surface = courseJson.getString("surface"),
                distance = courseJson.getInt("distance"),
                distanceCategory = courseJson.getString(
                    "distanceCategory"
                ),
                direction = courseJson.getString("direction"),
                season = courseJson.getString("season"),
                weather = courseJson.nullableString("weather"),
                groundCondition = courseJson.nullableString(
                    "groundCondition"
                ),
                courseTags = courseJson
                    .optJSONArray("courseTags")
                    .toStringList()
            ),
            runningStyles = runningStyles,
            sources = root
                .optJSONArray("sources")
                .toObjectList(::parseSource),
            metadata = MetadataData(
                generatedAt = metadataJson.nullableString(
                    "generatedAt"
                ),
                generator = metadataJson.nullableString(
                    "generator"
                ),
                sourceSite = metadataJson.nullableString(
                    "sourceSite"
                ),
                isComplete = metadataJson.optBoolean(
                    "isComplete",
                    false
                ),
                isSample = metadataJson.optBoolean(
                    "isSample",
                    false
                ),
                availableStyles = metadataJson
                    .optJSONArray("availableStyles")
                    .toStringList(),
                waitingStyles = metadataJson
                    .optJSONArray("waitingStyles")
                    .toStringList()
            )
        )
    }

    private fun parseRunningStyle(
        json: JSONObject
    ): RunningStyleData =
        RunningStyleData(
            displayName = json.getString("displayName"),
            contentStatus = json.getString("contentStatus"),
            targetStats = parseTargetStats(
                json.optJSONObject("targetStats")
            ),
            recommendedAptitudes = json
                .optJSONArray("recommendedAptitudes")
                .toObjectList(::parseRecommendedAptitude),
            skills = json
                .optJSONArray("skills")
                .toObjectList(::parseSkill),
            notes = json
                .optJSONArray("notes")
                .toObjectList(::parseNote),
            sourceIds = json
                .optJSONArray("sourceIds")
                .toStringList(),
            updatedAt = json.nullableString("updatedAt")
        )

    private fun parseTargetStats(
        json: JSONObject?
    ): TargetStatsData =
        TargetStatsData(
            speed = json
                ?.optJSONObject("speed")
                ?.let(::parseStatTarget),
            stamina = json
                ?.optJSONObject("stamina")
                ?.let(::parseStatTarget),
            power = json
                ?.optJSONObject("power")
                ?.let(::parseStatTarget),
            guts = json
                ?.optJSONObject("guts")
                ?.let(::parseStatTarget),
            wisdom = json
                ?.optJSONObject("wisdom")
                ?.let(::parseStatTarget)
        )

    private fun parseStatTarget(
        json: JSONObject
    ): StatTargetData {
        val value =
            if (
                json.has("value") &&
                !json.isNull("value")
            ) {
                json.getInt("value")
            } else {
                null
            }

        return StatTargetData(
            value = value,
            operator = json.nullableString("operator"),
            display = json.nullableString("display")
        )
    }

    private fun parseRecommendedAptitude(
        json: JSONObject
    ): RecommendedAptitudeData =
        RecommendedAptitudeData(
            type = json.getString("type"),
            target = json.getString("target"),
            recommendedRank = json.nullableString(
                "recommendedRank"
            ),
            priority = json.nullableString("priority"),
            note = json.nullableString("note")
        )

    private fun parseSkill(
        json: JSONObject
    ): SkillData =
        SkillData(
            id = json.getString("id"),
            name = json.getString("name"),
            aliases = json
                .optJSONArray("aliases")
                .toStringList(),
            category = json.getString("category"),
            grade = json.getString("grade"),
            effectiveness = json.nullableString(
                "effectiveness"
            ),
            priority =
                if (
                    json.has("priority") &&
                    !json.isNull("priority")
                ) {
                    json.getInt("priority")
                } else {
                    null
                },
            isRecommended = json.optBoolean(
                "isRecommended",
                false
            ),
            reason = json.nullableString("reason"),
            conditions = json
                .optJSONArray("conditions")
                .toStringList(),
            sourceIds = json
                .optJSONArray("sourceIds")
                .toStringList()
        )

    private fun parseNote(
        json: JSONObject
    ): NoteData =
        NoteData(
            type = json.getString("type"),
            text = json.getString("text")
        )

    private fun parseSource(
        json: JSONObject
    ): SourceData =
        SourceData(
            id = json.getString("id"),
            siteName = json.getString("siteName"),
            title = json.getString("title"),
            url = json.getString("url"),
            articleType = json.getString("articleType"),
            runningStyle = json.nullableString(
                "runningStyle"
            ),
            publishedAt = json.nullableString(
                "publishedAt"
            ),
            checkedAt = json.nullableString("checkedAt")
        )

    private companion object {
        const val FALLBACK_ASSET_NAME =
            "champions_meeting.json"

        const val REMOTE_CONFIG_ASSET =
            "remote_config.json"

        const val CACHE_DIRECTORY_NAME =
            "downloaded_data"

        const val CACHE_FILE_NAME =
            "latest.json"

        const val UPDATE_PREFS_NAME =
            "remote_update_metadata"

        const val KEY_ETAG = "etag"
        const val KEY_LAST_MODIFIED = "last_modified"
        const val KEY_SOURCE_URL = "source_url"
        const val KEY_LAST_SUCCESS_EPOCH_MS =
            "last_success_epoch_ms"

        const val DEFAULT_CONNECT_TIMEOUT_MS = 10_000
        const val DEFAULT_READ_TIMEOUT_MS = 15_000
        const val DEFAULT_MAX_PAYLOAD_BYTES =
            2 * 1024 * 1024

        val REQUIRED_STYLE_KEYS = listOf(
            "nige",
            "senko",
            "sashi",
            "oikomi"
        )
    }
}

private fun JSONObject.nullableString(
    key: String
): String? {
    if (!has(key) || isNull(key)) {
        return null
    }

    return getString(key)
        .takeIf { it.isNotBlank() }
}

private fun JSONArray?.toStringList(): List<String> {
    if (this == null) {
        return emptyList()
    }

    return buildList {
        for (index in 0 until length()) {
            add(getString(index))
        }
    }
}

private fun <T> JSONArray?.toObjectList(
    mapper: (JSONObject) -> T
): List<T> {
    if (this == null) {
        return emptyList()
    }

    return buildList {
        for (index in 0 until length()) {
            add(
                mapper(
                    getJSONObject(index)
                )
            )
        }
    }
}
