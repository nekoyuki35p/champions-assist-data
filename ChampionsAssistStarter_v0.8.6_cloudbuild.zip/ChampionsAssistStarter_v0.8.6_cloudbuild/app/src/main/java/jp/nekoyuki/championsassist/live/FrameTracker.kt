package jp.nekoyuki.championsassist.live

import android.media.Image
import kotlin.math.abs
import kotlin.math.sqrt

class FrameTracker {

    fun buildFrame(
        image: Image
    ): TrackingFrame? {
        if (
            image.width <= 0 ||
            image.height <= 0 ||
            image.planes.isEmpty()
        ) {
            return null
        }

        val plane =
            image.planes[0]

        val buffer =
            plane.buffer

        val pixelStride =
            plane.pixelStride

        val rowStride =
            plane.rowStride

        if (
            pixelStride < 3 ||
            rowStride <= 0
        ) {
            return null
        }

        val sourceWidth =
            image.width

        val sourceHeight =
            image.height

        val roiTop =
            (
                sourceHeight *
                ROI_TOP_PERCENT
            ) / 100

        val roiBottom =
            (
                sourceHeight *
                ROI_BOTTOM_PERCENT
            ) / 100

        val safeBottom =
            roiBottom.coerceIn(
                roiTop + 2,
                sourceHeight
            )

        val signatures =
            listOf(
                XBand(4, 12),
                XBand(12, 20),
                XBand(20, 28)
            ).map { band ->
                buildBandSignature(
                    buffer =
                        buffer,
                    sourceWidth =
                        sourceWidth,
                    roiTop =
                        roiTop,
                    roiBottom =
                        safeBottom,
                    pixelStride =
                        pixelStride,
                    rowStride =
                        rowStride,
                    band =
                        band
                )
            }

        return TrackingFrame(
            sourceWidth =
                sourceWidth,
            sourceHeight =
                sourceHeight,
            roiTop =
                roiTop,
            roiBottom =
                safeBottom,
            signatures =
                signatures
        )
    }

    fun estimateMotion(
        previous: TrackingFrame,
        current: TrackingFrame
    ): MotionEstimate {
        if (
            previous.sourceWidth !=
            current.sourceWidth ||
            previous.sourceHeight !=
            current.sourceHeight ||
            previous.signatures.size !=
            current.signatures.size
        ) {
            return MotionEstimate(
                dy = 0f,
                confidence = 0f,
                sceneChanged = true,
                validBands = 0,
                correlation = 0f
            )
        }

        val results =
            previous.signatures
                .zip(
                    current.signatures
                )
                .map {
                    estimateBandShift(
                        previous =
                            it.first,
                        current =
                            it.second
                    )
                }

        val valid =
            results.filter {
                it.bestScore >=
                MIN_VALID_CORRELATION
            }

        if (
            valid.isEmpty()
        ) {
            return MotionEstimate(
                dy = 0f,
                confidence = 0f,
                sceneChanged = true,
                validBands = 0,
                correlation =
                    results
                        .maxOfOrNull {
                            it.bestScore
                        }
                        ?: 0f
            )
        }

        val shifts =
            valid
                .map {
                    it.shift
                }
                .sorted()

        val medianShift =
            shifts[
                shifts.size / 2
            ]

        val agreement =
            valid.count {
                abs(
                    it.shift -
                    medianShift
                ) <=
                BAND_SHIFT_TOLERANCE_ROWS
            }.toFloat() /
            valid.size.toFloat()

        val avgCorrelation =
            valid
                .map {
                    it.bestScore
                }
                .average()
                .toFloat()

        val avgUniqueness =
            valid
                .map {
                    it.uniqueness
                }
                .average()
                .toFloat()
                .coerceIn(
                    0f,
                    0.25f
                )

        val confidence =
            (
                avgCorrelation *
                0.65f +
                agreement *
                0.25f +
                (
                    avgUniqueness /
                    0.25f
                ) *
                0.10f
            )
                .coerceIn(
                    0f,
                    1f
                )

        val roiHeight =
            (
                current.roiBottom -
                current.roiTop
            )
                .coerceAtLeast(
                    1
                )

        val pixelsPerProfileRow =
            roiHeight.toFloat() /
            PROFILE_ROWS.toFloat()

        val dy =
            medianShift *
            pixelsPerProfileRow

        val sceneChanged =
            (
                valid.size < 2 &&
                avgCorrelation <
                SCENE_CHANGE_CORRELATION
            ) ||
            (
                agreement <
                0.34f &&
                avgCorrelation <
                0.50f
            )

        return MotionEstimate(
            dy = dy,
            confidence =
                confidence,
            sceneChanged =
                sceneChanged,
            validBands =
                valid.size,
            correlation =
                avgCorrelation
        )
    }

    private fun buildBandSignature(
        buffer: java.nio.ByteBuffer,
        sourceWidth: Int,
        roiTop: Int,
        roiBottom: Int,
        pixelStride: Int,
        rowStride: Int,
        band: XBand
    ): FloatArray {
        val xStart =
            (
                sourceWidth *
                band.startPercent
            ) / 100

        val xEnd =
            (
                sourceWidth *
                band.endPercent
            ) / 100

        val safeXEnd =
            xEnd.coerceIn(
                xStart + 2,
                sourceWidth
            )

        val rowMeans =
            FloatArray(
                PROFILE_ROWS
            )

        for (
            row in
            0 until PROFILE_ROWS
        ) {
            val sourceY =
                roiTop +
                (
                    (
                        roiBottom -
                        roiTop -
                        1
                    ) *
                    row
                ) /
                (
                    PROFILE_ROWS -
                    1
                )

            var sum =
                0f

            var samples =
                0

            for (
                sample in
                0 until X_SAMPLES_PER_BAND
            ) {
                val sourceX =
                    xStart +
                    (
                        (
                            safeXEnd -
                            xStart -
                            1
                        ) *
                        sample
                    ) /
                    (
                        X_SAMPLES_PER_BAND -
                        1
                    )

                val index =
                    sourceY *
                    rowStride +
                    sourceX *
                    pixelStride

                if (
                    index < 0 ||
                    index + 2 >=
                    buffer.limit()
                ) {
                    continue
                }

                val r =
                    buffer
                        .get(
                            index
                        )
                        .toInt() and
                    0xFF

                val g =
                    buffer
                        .get(
                            index + 1
                        )
                        .toInt() and
                    0xFF

                val b =
                    buffer
                        .get(
                            index + 2
                        )
                        .toInt() and
                    0xFF

                val luma =
                    (
                        77 * r +
                        150 * g +
                        29 * b
                    ) shr
                    8

                sum +=
                    luma.toFloat()

                samples++
            }

            rowMeans[row] =
                if (
                    samples > 0
                ) {
                    sum /
                    samples.toFloat()
                } else {
                    0f
                }
        }

        val edges =
            FloatArray(
                PROFILE_ROWS
            )

        for (
            row in
            1 until PROFILE_ROWS - 1
        ) {
            edges[row] =
                abs(
                    rowMeans[
                        row + 1
                    ] -
                    rowMeans[
                        row - 1
                    ]
                )
        }

        return zeroMean(
            edges
        )
    }

    private fun estimateBandShift(
        previous: FloatArray,
        current: FloatArray
    ): BandShiftResult {
        val scores =
            mutableListOf<
                Pair<Int, Float>
            >()

        var bestShift =
            0

        var bestScore =
            -1f

        for (
            shift in
            -MAX_SHIFT_ROWS..
            MAX_SHIFT_ROWS
        ) {
            val score =
                normalizedCorrelation(
                    previous =
                        previous,
                    current =
                        current,
                    shift =
                        shift
                )

            scores +=
                shift to score

            if (
                score >
                bestScore
            ) {
                bestScore =
                    score

                bestShift =
                    shift
            }
        }

        val secondBest =
            scores
                .asSequence()
                .filter {
                    abs(
                        it.first -
                        bestShift
                    ) >=
                    SECOND_BEST_DISTANCE_ROWS
                }
                .maxOfOrNull {
                    it.second
                }
                ?: -1f

        return BandShiftResult(
            shift =
                bestShift,
            bestScore =
                bestScore,
            uniqueness =
                (
                    bestScore -
                    secondBest
                )
                    .coerceAtLeast(
                        0f
                    )
        )
    }

    private fun normalizedCorrelation(
        previous: FloatArray,
        current: FloatArray,
        shift: Int
    ): Float {
        var dot =
            0f

        var previousEnergy =
            0f

        var currentEnergy =
            0f

        var count =
            0

        for (
            row in
            previous.indices
        ) {
            val currentRow =
                row +
                shift

            if (
                currentRow !in
                current.indices
            ) {
                continue
            }

            val a =
                previous[row]

            val b =
                current[
                    currentRow
                ]

            dot +=
                a * b

            previousEnergy +=
                a * a

            currentEnergy +=
                b * b

            count++
        }

        if (
            count <
            MIN_OVERLAP_ROWS ||
            previousEnergy <=
            0.0001f ||
            currentEnergy <=
            0.0001f
        ) {
            return -1f
        }

        return (
            dot /
            sqrt(
                previousEnergy *
                currentEnergy
            )
        )
            .coerceIn(
                -1f,
                1f
            )
    }

    private fun zeroMean(
        values: FloatArray
    ): FloatArray {
        val mean =
            values
                .average()
                .toFloat()

        return FloatArray(
            values.size
        ) {
            index ->
            values[index] -
            mean
        }
    }

    private data class XBand(
        val startPercent: Int,
        val endPercent: Int
    )

    private data class BandShiftResult(
        val shift: Int,
        val bestScore: Float,
        val uniqueness: Float
    )

    private companion object {
        const val ROI_TOP_PERCENT =
            29

        const val ROI_BOTTOM_PERCENT =
            90

        const val PROFILE_ROWS =
            180

        const val X_SAMPLES_PER_BAND =
            9

        const val MAX_SHIFT_ROWS =
            48

        const val MIN_OVERLAP_ROWS =
            90

        const val SECOND_BEST_DISTANCE_ROWS =
            4

        const val BAND_SHIFT_TOLERANCE_ROWS =
            4

        const val MIN_VALID_CORRELATION =
            0.38f

        const val SCENE_CHANGE_CORRELATION =
            0.30f
    }
}
