package jp.nekoyuki.championsassist.live

import android.content.Context
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import jp.nekoyuki.championsassist.settings.AssistSettings

class OverlayController(
    private val context: Context
) {
    private val windowManager =
        context.getSystemService(
            Context.WINDOW_SERVICE
        ) as WindowManager

    private var overlayView:
        SkillOverlayView? =
        null

    fun canDraw(): Boolean =
        Settings.canDrawOverlays(
            context
        )

    fun ensureAttached() {
        if (
            overlayView != null ||
            !canDraw()
        ) {
            return
        }

        val view =
            SkillOverlayView(
                context
            )

        val params =
            WindowManager
                .LayoutParams(
                    WindowManager
                        .LayoutParams
                        .MATCH_PARENT,
                    WindowManager
                        .LayoutParams
                        .MATCH_PARENT,
                    WindowManager
                        .LayoutParams
                        .TYPE_APPLICATION_OVERLAY,
                    WindowManager
                        .LayoutParams
                        .FLAG_NOT_FOCUSABLE or
                    WindowManager
                        .LayoutParams
                        .FLAG_NOT_TOUCHABLE or
                    WindowManager
                        .LayoutParams
                        .FLAG_LAYOUT_NO_LIMITS or
                    WindowManager
                        .LayoutParams
                        .FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat
                        .TRANSLUCENT
                )
                .apply {
                    gravity =
                        Gravity.TOP or
                        Gravity.START
                }

        windowManager.addView(
            view,
            params
        )

        overlayView =
            view
    }

    fun showTrackedLabels(
        labels:
            List<TrackedSkillLabel>,
        sourceWidth: Int,
        sourceHeight: Int,
        settings:
            AssistSettings
    ) {
        ensureAttached()

        overlayView
            ?.apply {
                visibility =
                    View.VISIBLE

                updateTrackedLabels(
                    labels =
                        labels,
                    sourceWidth =
                        sourceWidth,
                    sourceHeight =
                        sourceHeight,
                    settings =
                        settings
                )
            }
    }

    fun clear() {
        overlayView
            ?.clearMatches()
    }

    fun detach() {
        val view =
            overlayView
                ?: return

        runCatching {
            windowManager
                .removeView(
                    view
                )
        }

        overlayView =
            null
    }
}
