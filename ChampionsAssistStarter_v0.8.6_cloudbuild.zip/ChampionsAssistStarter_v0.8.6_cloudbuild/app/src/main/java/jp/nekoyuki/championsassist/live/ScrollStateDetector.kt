package jp.nekoyuki.championsassist.live

import kotlin.math.abs

class ScrollStateDetector {

    private var stillFrames =
        0

    private var lostFrames =
        0

    private var lastState =
        ScrollState.STOPPED

    fun update(
        motion: MotionEstimate
    ): ScrollState {
        val unreliable =
            motion.sceneChanged ||
            motion.confidence <
            LOST_CONFIDENCE

        if (
            unreliable
        ) {
            lostFrames++

            if (
                lostFrames >=
                LOST_FRAME_LIMIT
            ) {
                lastState =
                    ScrollState.LOST
            }

            return lastState
        }

        lostFrames =
            0

        if (
            abs(
                motion.dy
            ) <=
            STILL_DY_PX
        ) {
            stillFrames++
        } else {
            stillFrames =
                0
        }

        lastState =
            if (
                stillFrames >=
                STOPPED_FRAME_LIMIT
            ) {
                ScrollState.STOPPED
            } else {
                ScrollState.SCROLLING
            }

        return lastState
    }

    fun reset() {
        stillFrames =
            0

        lostFrames =
            0

        lastState =
            ScrollState.STOPPED
    }

    private companion object {
        const val STILL_DY_PX =
            2.5f

        const val LOST_CONFIDENCE =
            0.30f

        const val LOST_FRAME_LIMIT =
            3

        const val STOPPED_FRAME_LIMIT =
            3
    }
}
