package jp.nekoyuki.championsassist

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import jp.nekoyuki.championsassist.ui.home.HomeRoute
import jp.nekoyuki.championsassist.ui.theme.ChampionsAssistTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ChampionsAssistTheme {
                HomeRoute()
            }
        }
    }
}
