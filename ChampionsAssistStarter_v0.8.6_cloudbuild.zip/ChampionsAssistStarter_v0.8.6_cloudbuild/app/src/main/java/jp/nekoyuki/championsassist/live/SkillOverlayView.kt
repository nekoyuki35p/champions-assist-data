package jp.nekoyuki.championsassist.live

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import jp.nekoyuki.championsassist.settings.AssistSettings

class SkillOverlayView(
    context: Context
) : View(context) {

    private var labels:
        List<TrackedSkillLabel> =
        emptyList()

    private var sourceWidth =
        1

    private var sourceHeight =
        1

    private var settings =
        AssistSettings()

    private val fillPaint =
        Paint(
            Paint.ANTI_ALIAS_FLAG
        )

    private val borderPaint =
        Paint(
            Paint.ANTI_ALIAS_FLAG
        ).apply {
            style =
                Paint.Style.STROKE
        }

    private val textPaint =
        Paint(
            Paint.ANTI_ALIAS_FLAG
        ).apply {
            color =
                Color.WHITE

            typeface =
                android.graphics
                    .Typeface
                    .DEFAULT_BOLD
        }

    fun updateTrackedLabels(
        labels:
            List<TrackedSkillLabel>,
        sourceWidth: Int,
        sourceHeight: Int,
        settings:
            AssistSettings
    ) {
        this.labels =
            labels

        this.sourceWidth =
            sourceWidth
                .coerceAtLeast(
                    1
                )

        this.sourceHeight =
            sourceHeight
                .coerceAtLeast(
                    1
                )

        this.settings =
            settings

        invalidate()
    }

    fun clearMatches() {
        labels =
            emptyList()

        invalidate()
    }

    override fun onDraw(
        canvas: Canvas
    ) {
        super.onDraw(
            canvas
        )

        val scaleX =
            width.toFloat() /
            sourceWidth.toFloat()

        val scaleY =
            height.toFloat() /
            sourceHeight.toFloat()

        val labelScale =
            settings
                .overlayLabelScale
                .coerceIn(
                    0.65f,
                    1.8f
                )

        textPaint.textSize =
            34f *
            labelScale

        borderPaint.strokeWidth =
            4f *
            labelScale

        labels.forEach {
            tracked ->

            if (
                !tracked.visible
            ) {
                return@forEach
            }

            val mapped =
                RectF(
                    tracked.left *
                        scaleX +
                        settings
                            .overlayOffsetX,
                    tracked.top *
                        scaleY +
                        settings
                            .overlayOffsetY,
                    tracked.right *
                        scaleX +
                        settings
                            .overlayOffsetX,
                    tracked.bottom *
                        scaleY +
                        settings
                            .overlayOffsetY
                )

            if (
                mapped.bottom <
                0f ||
                mapped.top >
                height.toFloat()
            ) {
                return@forEach
            }

            val gradeColor =
                colorForGrade(
                    tracked.grade
                )

            if (
                settings
                    .showBoundingBoxes
            ) {
                borderPaint.color =
                    gradeColor

                fillPaint.color =
                    Color.argb(
                        38,
                        Color.red(
                            gradeColor
                        ),
                        Color.green(
                            gradeColor
                        ),
                        Color.blue(
                            gradeColor
                        )
                    )

                canvas.drawRoundRect(
                    mapped,
                    12f *
                        labelScale,
                    12f *
                        labelScale,
                    fillPaint
                )

                canvas.drawRoundRect(
                    mapped,
                    12f *
                        labelScale,
                    12f *
                        labelScale,
                    borderPaint
                )
            }

            val grade =
                tracked.grade
                    .uppercase()

            val pad =
                13f *
                labelScale

            val labelWidth =
                textPaint
                    .measureText(
                        grade
                    ) +
                pad *
                2f

            val labelHeight =
                48f *
                labelScale

            var labelLeft =
                mapped.right +
                10f *
                labelScale

            if (
                labelLeft +
                labelWidth >
                width
            ) {
                labelLeft =
                    mapped.left -
                    labelWidth -
                    10f *
                    labelScale
            }

            val labelTop =
                (
                    mapped.centerY() -
                    labelHeight /
                    2f
                )
                    .coerceIn(
                        0f,
                        (
                            height -
                            labelHeight
                        )
                            .coerceAtLeast(
                                0f
                            )
                    )

            val labelRect =
                RectF(
                    labelLeft,
                    labelTop,
                    labelLeft +
                        labelWidth,
                    labelTop +
                        labelHeight
                )

            fillPaint.color =
                gradeColor

            canvas.drawRoundRect(
                labelRect,
                12f *
                    labelScale,
                12f *
                    labelScale,
                fillPaint
            )

            canvas.drawText(
                grade,
                labelRect.left +
                    pad,
                labelRect.bottom -
                    10f *
                    labelScale,
                textPaint
            )
        }
    }

    private fun colorForGrade(
        grade: String
    ): Int =
        when (
            grade.uppercase()
        ) {
            "S" ->
                Color.rgb(
                    36,
                    161,
                    72
                )

            "A" ->
                Color.rgb(
                    47,
                    105,
                    204
                )

            "B" ->
                Color.rgb(
                    217,
                    139,
                    25
                )

            else ->
                Color.rgb(
                    110,
                    110,
                    110
                )
        }
}
