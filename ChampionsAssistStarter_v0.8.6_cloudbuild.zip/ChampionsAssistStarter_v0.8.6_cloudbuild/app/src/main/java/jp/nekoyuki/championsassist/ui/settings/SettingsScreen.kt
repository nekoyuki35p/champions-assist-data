package jp.nekoyuki.championsassist.ui.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import jp.nekoyuki.championsassist.debug.DebugLog
import jp.nekoyuki.championsassist.settings.AssistSettings
import jp.nekoyuki.championsassist.settings.AssistSettingsStore
import jp.nekoyuki.championsassist.ui.AppDestination
import kotlin.math.roundToInt

@OptIn(
    ExperimentalMaterial3Api::class
)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onNavigate:
        (AppDestination) -> Unit
) {
    val context =
        LocalContext.current
            .applicationContext

    val settingsStore =
        remember {
            AssistSettingsStore(
                context
            )
        }

    val debugLog =
        remember {
            DebugLog(
                context
            )
        }

    var settings
        by remember {
            mutableStateOf(
                settingsStore
                    .load()
            )
        }

    var logText
        by remember {
            mutableStateOf(
                debugLog
                    .readRecent(
                        80
                    )
            )
        }

    fun update(
        newSettings:
            AssistSettings
    ) {
        settings =
            newSettings

        settingsStore
            .save(
                newSettings
            )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text =
                            "設定・実機調整",
                        fontWeight =
                            FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick =
                            onBack
                    ) {
                        Icon(
                            imageVector =
                                Icons.Default
                                    .ArrowBack,
                            contentDescription =
                                "戻る"
                        )
                    }
                }
            )
        },
        bottomBar = {
            SettingsBottomNavigation(
                onNavigate =
                    onNavigate
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(
                        innerPadding
                    ),
            contentPadding =
                PaddingValues(
                    start =
                        16.dp,
                    end =
                        16.dp,
                    top =
                        12.dp,
                    bottom =
                        28.dp
                ),
            verticalArrangement =
                Arrangement
                    .spacedBy(
                        14.dp
                    )
        ) {
            item {
                SettingsCard(
                    title =
                        "表示する評価"
                ) {
                    ToggleRow(
                        label = "S",
                        checked =
                            settings
                                .showGradeS,
                        onCheckedChange = {
                            update(
                                settings.copy(
                                    showGradeS =
                                        it
                                )
                            )
                        }
                    )

                    ToggleRow(
                        label = "A",
                        checked =
                            settings
                                .showGradeA,
                        onCheckedChange = {
                            update(
                                settings.copy(
                                    showGradeA =
                                        it
                                )
                            )
                        }
                    )

                    ToggleRow(
                        label = "B",
                        checked =
                            settings
                                .showGradeB,
                        onCheckedChange = {
                            update(
                                settings.copy(
                                    showGradeB =
                                        it
                                )
                            )
                        }
                    )
                }
            }

            item {
                SettingsCard(
                    title =
                        "OCR認識"
                ) {
                    Text(
                        text =
                            "最低一致度 ${(settings.minConfidence * 100f).roundToInt()}%",
                        fontWeight =
                            FontWeight
                                .SemiBold
                    )

                    Slider(
                        value =
                            settings
                                .minConfidence,
                        onValueChange = {
                            update(
                                settings.copy(
                                    minConfidence =
                                        it
                                )
                            )
                        },
                        valueRange =
                            0.75f..0.98f
                    )

                    Text(
                        text =
                            "低くすると拾いやすく、高くすると誤認識を減らせます。",
                        style =
                            MaterialTheme
                                .typography
                                .bodySmall
                    )

                    Spacer(
                        Modifier.height(
                            12.dp
                        )
                    )

                    Text(
                        text =
                            "OCR再補正間隔 ${settings.scanIntervalMs} ms",
                        fontWeight =
                            FontWeight
                                .SemiBold
                    )

                    Slider(
                        value =
                            settings
                                .scanIntervalMs
                                .toFloat(),
                        onValueChange = {
                            update(
                                settings.copy(
                                    scanIntervalMs =
                                        (
                                            it /
                                            50f
                                        )
                                            .roundToInt()
                                            .times(
                                                50L
                                            )
                                            .coerceIn(
                                                250L,
                                                2000L
                                            )
                                )
                            )
                        },
                        valueRange =
                            250f..2000f
                    )

                    Text(
                        text =
                            "追従は約45ms周期。ここはOCRで位置を再確認する間隔です。350〜500ms前後を推奨。",
                        style =
                            MaterialTheme
                                .typography
                                .bodySmall
                    )
                }
            }

            item {
                SettingsCard(
                    title =
                        "オーバーレイ位置補正"
                ) {
                    Text(
                        text =
                            "X補正 ${settings.overlayOffsetX}px",
                        fontWeight =
                            FontWeight
                                .SemiBold
                    )

                    Slider(
                        value =
                            settings
                                .overlayOffsetX
                                .toFloat(),
                        onValueChange = {
                            update(
                                settings.copy(
                                    overlayOffsetX =
                                        (
                                            it /
                                            5f
                                        )
                                            .roundToInt()
                                            .times(
                                                5
                                            )
                                )
                            )
                        },
                        valueRange =
                            -250f..250f
                    )

                    Text(
                        text =
                            "Y補正 ${settings.overlayOffsetY}px",
                        fontWeight =
                            FontWeight
                                .SemiBold
                    )

                    Slider(
                        value =
                            settings
                                .overlayOffsetY
                                .toFloat(),
                        onValueChange = {
                            update(
                                settings.copy(
                                    overlayOffsetY =
                                        (
                                            it /
                                            5f
                                        )
                                            .roundToInt()
                                            .times(
                                                5
                                            )
                                )
                            )
                        },
                        valueRange =
                            -250f..250f
                    )

                    Text(
                        text =
                            "ラベル倍率 ${String.format("%.2f", settings.overlayLabelScale)}x",
                        fontWeight =
                            FontWeight
                                .SemiBold
                    )

                    Slider(
                        value =
                            settings
                                .overlayLabelScale,
                        onValueChange = {
                            update(
                                settings.copy(
                                    overlayLabelScale =
                                        it
                                )
                            )
                        },
                        valueRange =
                            0.7f..1.5f
                    )

                    ToggleRow(
                        label =
                            "スキル文字を枠で囲む",
                        checked =
                            settings
                                .showBoundingBoxes,
                        onCheckedChange = {
                            update(
                                settings.copy(
                                    showBoundingBoxes =
                                        it
                                )
                            )
                        }
                    )

                    Spacer(
                        Modifier.height(
                            8.dp
                        )
                    )

                    OutlinedButton(
                        onClick = {
                            settings =
                                settingsStore
                                    .reset()
                        },
                        modifier =
                            Modifier
                                .fillMaxWidth()
                    ) {
                        Text(
                            "表示設定を初期値へ戻す"
                        )
                    }
                }
            }

            item {
                SettingsCard(
                    title =
                        "デバッグログ"
                ) {
                    Text(
                        text =
                            "実機テスト時の画面サイズ・OCR件数・一致件数・エラーを記録します。",
                        style =
                            MaterialTheme
                                .typography
                                .bodyMedium
                    )

                    Spacer(
                        Modifier.height(
                            6.dp
                        )
                    )

                    Text(
                        text =
                            debugLog.path(),
                        style =
                            MaterialTheme
                                .typography
                                .bodySmall
                    )

                    Spacer(
                        Modifier.height(
                            10.dp
                        )
                    )

                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth(),
                        horizontalArrangement =
                            Arrangement
                                .spacedBy(
                                    8.dp
                                )
                    ) {
                        OutlinedButton(
                            onClick = {
                                logText =
                                    debugLog
                                        .readRecent(
                                            80
                                        )
                            },
                            modifier =
                                Modifier
                                    .weight(
                                        1f
                                    )
                        ) {
                            Icon(
                                imageVector =
                                    Icons.Default
                                        .Refresh,
                                contentDescription =
                                    null
                            )

                            Text(
                                "更新"
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                val clipboard =
                                    context
                                        .getSystemService(
                                            Context.CLIPBOARD_SERVICE
                                        ) as
                                    ClipboardManager

                                clipboard
                                    .setPrimaryClip(
                                        ClipData
                                            .newPlainText(
                                                "Champions Assist log",
                                                logText
                                            )
                                    )
                            },
                            modifier =
                                Modifier
                                    .weight(
                                        1f
                                    )
                        ) {
                            Icon(
                                imageVector =
                                    Icons.Default
                                        .ContentCopy,
                                contentDescription =
                                    null
                            )

                            Text(
                                "コピー"
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                debugLog
                                    .clear()

                                logText =
                                    debugLog
                                        .readRecent(
                                            80
                                        )
                            },
                            modifier =
                                Modifier
                                    .weight(
                                        1f
                                    )
                        ) {
                            Icon(
                                imageVector =
                                    Icons.Default
                                        .Delete,
                                contentDescription =
                                    null
                            )

                            Text(
                                "消去"
                            )
                        }
                    }

                    Spacer(
                        Modifier.height(
                            10.dp
                        )
                    )

                    Text(
                        text =
                            logText,
                        style =
                            MaterialTheme
                                .typography
                                .bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(
    title: String,
    content:
        @Composable
        ColumnScope.() -> Unit
) {
    Card(
        modifier =
            Modifier
                .fillMaxWidth()
    ) {
        Column(
            modifier =
                Modifier
                    .padding(
                        16.dp
                    )
        ) {
            Text(
                text =
                    title,
                style =
                    MaterialTheme
                        .typography
                        .titleMedium,
                fontWeight =
                    FontWeight.Bold
            )

            Spacer(
                Modifier.height(
                    10.dp
                )
            )

            content()
        }
    }
}

@Composable
private fun ToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange:
        (Boolean) -> Unit
) {
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    vertical =
                        4.dp
                ),
        verticalAlignment =
            Alignment
                .CenterVertically
    ) {
        Text(
            text =
                label,
            modifier =
                Modifier
                    .weight(
                        1f
                    )
        )

        Switch(
            checked =
                checked,
            onCheckedChange =
                onCheckedChange
        )
    }
}

@Composable
private fun SettingsBottomNavigation(
    onNavigate:
        (AppDestination) -> Unit
) {
    NavigationBar {
        NavigationBarItem(
            selected =
                false,
            onClick = {
                onNavigate(
                    AppDestination.HOME
                )
            },
            icon = {
                Icon(
                    Icons.Default
                        .Home,
                    contentDescription =
                        null
                )
            },
            label = {
                Text(
                    "ホーム"
                )
            }
        )

        NavigationBarItem(
            selected =
                false,
            onClick = {
                onNavigate(
                    AppDestination.SKILLS
                )
            },
            icon = {
                Icon(
                    Icons.Default
                        .Search,
                    contentDescription =
                        null
                )
            },
            label = {
                Text(
                    "スキル"
                )
            }
        )

        NavigationBarItem(
            selected =
                false,
            onClick = {
                onNavigate(
                    AppDestination.ASSIST
                )
            },
            icon = {
                Icon(
                    Icons.Default
                        .CenterFocusStrong,
                    contentDescription =
                        null
                )
            },
            label = {
                Text(
                    "アシスト"
                )
            }
        )

        NavigationBarItem(
            selected =
                true,
            onClick = {},
            icon = {
                Icon(
                    Icons.Default
                        .Settings,
                    contentDescription =
                        null
                )
            },
            label = {
                Text(
                    "設定"
                )
            }
        )
    }
}
