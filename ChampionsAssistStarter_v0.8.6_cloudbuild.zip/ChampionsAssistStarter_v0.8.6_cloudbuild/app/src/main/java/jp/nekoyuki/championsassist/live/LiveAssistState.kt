package jp.nekoyuki.championsassist.live

enum class LiveAssistStatus {
    STOPPED,
    STARTING,
    RUNNING,
    ERROR
}

data class LiveAssistState(
    val status: LiveAssistStatus,
    val message: String,
    val recognizedCount: Int = 0
)
