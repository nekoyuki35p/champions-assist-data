package jp.nekoyuki.championsassist.live

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import jp.nekoyuki.championsassist.MainActivity
import jp.nekoyuki.championsassist.data.model.SkillData
import jp.nekoyuki.championsassist.data.repository.ChampionsMeetingRepository
import jp.nekoyuki.championsassist.debug.DebugLog
import jp.nekoyuki.championsassist.ocr.JapaneseOcrRecognizer
import jp.nekoyuki.championsassist.ocr.OcrResult
import jp.nekoyuki.championsassist.ocr.SkillAliasMatcher
import jp.nekoyuki.championsassist.settings.AssistSettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer

class MediaProjectionAssistService :
    Service(),
    DisplayManager.DisplayListener {

    private val serviceJob =
        SupervisorJob()

    private val scope =
        CoroutineScope(
            serviceJob +
            Dispatchers.Default
        )

    private lateinit var repository:
        ChampionsMeetingRepository

    private lateinit var recognizer:
        JapaneseOcrRecognizer

    private val matcher =
        SkillAliasMatcher()

    private lateinit var overlay:
        OverlayController

    private lateinit var settingsStore:
        AssistSettingsStore

    private lateinit var debugLog:
        DebugLog

    private var mediaProjection:
        MediaProjection? = null

    private var virtualDisplay:
        VirtualDisplay? = null

    private var imageReader:
        ImageReader? = null

    private var displayManager:
        DisplayManager? = null

    private var trackingJob:
        Job? = null

    private var ocrJob:
        Job? = null

    private val frameTracker =
        FrameTracker()

    private val labelStore =
        TrackedLabelStore()

    private val scrollDetector =
        ScrollStateDetector()

    @Volatile
    private var previousTrackingFrame:
        TrackingFrame? = null

    @Volatile
    private var currentScrollState =
        ScrollState.STOPPED

    @Volatile
    private var forceOcrRequested =
        true

    @Volatile
    private var lastOcrStartedAt =
        0L

    private var lastTrackingLogAt =
        0L

    private var currentSkills:
        List<SkillData> =
        emptyList()

    private var currentStyleKey:
        String = "sashi"

    private var captureWidth:
        Int = 1

    private var captureHeight:
        Int = 1

    private var captureDensityDpi:
        Int = DisplayMetrics
            .DENSITY_DEFAULT

    private val projectionCallback =
        object :
            MediaProjection.Callback() {

            override fun onStop() {
                scope.launch {
                    stopEverything(
                        "画面共有が終了しました。"
                    )
                }
            }

            override fun onCapturedContentResize(
                width: Int,
                height: Int
            ) {
                if (
                    width <= 0 ||
                    height <= 0
                ) {
                    return
                }

                scope.launch {
                    captureWidth =
                        width
                    captureHeight =
                        height

                    withContext(
                        Dispatchers.Main
                    ) {
                        createImageReaderAndDisplay()
                    }

                    resetTracking(
                        "capture resized"
                    )
                }
            }
        }

    override fun onCreate() {
        super.onCreate()

        repository =
            ChampionsMeetingRepository(
                applicationContext
            )

        recognizer =
            JapaneseOcrRecognizer(
                applicationContext
            )

        overlay =
            OverlayController(
                applicationContext
            )

        settingsStore =
            AssistSettingsStore(
                applicationContext
            )

        debugLog =
            DebugLog(
                applicationContext
            )

        debugLog.append(
            "Service onCreate"
        )

        displayManager =
            getSystemService(
                Context.DISPLAY_SERVICE
            ) as DisplayManager

        displayManager
            ?.registerDisplayListener(
                this,
                Handler(
                    Looper.getMainLooper()
                )
            )

        createNotificationChannel()
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {
        debugLog.append(
            "onStartCommand action=${intent?.action}"
        )
        when (
            intent?.action
        ) {
            ACTION_STOP -> {
                scope.launch {
                    stopEverything(
                        "アシストを停止しました。"
                    )
                }

                return START_NOT_STICKY
            }

            ACTION_UPDATE_STYLE -> {
                currentStyleKey =
                    intent
                        .getStringExtra(
                            EXTRA_STYLE
                        )
                        ?: currentStyleKey

                scope.launch {
                    loadStyleSkills()

                    resetTracking(
                        "style changed"
                    )
                }

                return START_STICKY
            }
        }

        val resultCode =
            intent?.getIntExtra(
                EXTRA_RESULT_CODE,
                Int.MIN_VALUE
            ) ?: Int.MIN_VALUE

        val projectionData =
            intent
                ?.projectionIntentExtra()

        currentStyleKey =
            intent
                ?.getStringExtra(
                    EXTRA_STYLE
                )
                ?: "sashi"

        if (
            resultCode ==
            Int.MIN_VALUE ||
            projectionData == null
        ) {
            updateState(
                LiveAssistState(
                    status =
                        LiveAssistStatus.ERROR,
                    message =
                        "画面共有許可データがありません。"
                )
            )
            stopSelf()
            return START_NOT_STICKY
        }

        startProjectionForeground()

        if (
            !overlay.canDraw()
        ) {
            updateState(
                LiveAssistState(
                    status =
                        LiveAssistStatus.ERROR,
                    message =
                        "他のアプリの上に表示する権限がありません。"
                )
            )

            stopSelf()
            return START_NOT_STICKY
        }

        if (
            mediaProjection == null
        ) {
            startProjection(
                resultCode =
                    resultCode,
                projectionData =
                    projectionData
            )
        }

        return START_NOT_STICKY
    }

    override fun onBind(
        intent: Intent?
    ): IBinder? =
        null

    private fun startProjection(
        resultCode: Int,
        projectionData: Intent
    ) {
        updateState(
            LiveAssistState(
                status =
                    LiveAssistStatus.STARTING,
                message =
                    "リアルタイムアシストを開始しています…"
            )
        )

        debugLog.append(
            "startProjection style=$currentStyleKey"
        )

        val manager =
            getSystemService(
                Context.MEDIA_PROJECTION_SERVICE
            ) as MediaProjectionManager

        val projection =
            manager.getMediaProjection(
                resultCode,
                projectionData
            )

        if (
            projection == null
        ) {
            debugLog.append(
                "getMediaProjection returned null"
            )

            updateState(
                LiveAssistState(
                    status =
                        LiveAssistStatus.ERROR,
                    message =
                        "画面共有を開始できませんでした。もう一度許可してください。"
                )
            )

            stopSelf()
            return
        }

        mediaProjection =
            projection

        projection.registerCallback(
            projectionCallback,
            Handler(
                Looper.getMainLooper()
            )
        )

        updateCaptureMetrics()
        createImageReaderAndDisplay()

        scope.launch {
            loadStyleSkills()

            withContext(
                Dispatchers.Main
            ) {
                overlay.ensureAttached()
            }

            startScanning()
        }
    }

    private suspend fun loadStyleSkills() {
        val loaded =
            runCatching {
                repository
                    .loadInitialData()
            }.getOrElse {
                updateState(
                    LiveAssistState(
                        status =
                            LiveAssistStatus.ERROR,
                        message =
                            "攻略JSONを読み込めませんでした。"
                    )
                )
                return
            }

        currentSkills =
            loaded.data
                .runningStyles[
                    currentStyleKey
                ]
                ?.skills
                .orEmpty()

        debugLog.append(
            "loadStyleSkills style=$currentStyleKey count=${currentSkills.size}"
        )
    }

    private fun createImageReaderAndDisplay() {
        val projection =
            mediaProjection
                ?: return

        imageReader?.close()

        val reader =
            ImageReader.newInstance(
                captureWidth,
                captureHeight,
                PixelFormat.RGBA_8888,
                3
            )

        imageReader =
            reader

        if (
            virtualDisplay == null
        ) {
            virtualDisplay =
                projection
                    .createVirtualDisplay(
                        "ChampionsAssistCapture",
                        captureWidth,
                        captureHeight,
                        captureDensityDpi,
                        DisplayManager
                            .VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                        reader.surface,
                        null,
                        null
                    )
        } else {
            virtualDisplay?.resize(
                captureWidth,
                captureHeight,
                captureDensityDpi
            )

            virtualDisplay
                ?.setSurface(
                    reader.surface
                )
        }
    }

private fun startScanning() {
    trackingJob?.cancel()

    trackingJob =
        scope.launch {
            updateState(
                LiveAssistState(
                    status =
                        LiveAssistStatus.RUNNING,
                    message =
                        "OCR＋スクロール追跡で監視中です。"
                )
            )

            var activeSettings =
                settingsStore
                    .load()

            var lastSettingsReloadAt =
                0L

            while (
                isActive
            ) {
                val cycleStartedAt =
                    SystemClock
                        .elapsedRealtime()

                if (
                    cycleStartedAt -
                    lastSettingsReloadAt >=
                    SETTINGS_RELOAD_MS
                ) {
                    activeSettings =
                        settingsStore
                            .load()

                    lastSettingsReloadAt =
                        cycleStartedAt
                }

                val image =
                    acquireLatestImageRaw()

                if (
                    image == null
                ) {
                    delay(
                        TRACKING_IDLE_MS
                    )
                    continue
                }

                try {
                    val frame =
                        frameTracker
                            .buildFrame(
                                image
                            )

                    val previous =
                        previousTrackingFrame

                    if (
                        frame != null
                    ) {
                        if (
                            previous != null
                        ) {
                            val motion =
                                frameTracker
                                    .estimateMotion(
                                        previous =
                                            previous,
                                        current =
                                            frame
                                    )

                            val oldState =
                                currentScrollState

                            val newState =
                                scrollDetector
                                    .update(
                                        motion
                                    )

                            currentScrollState =
                                newState

                            val now =
                                SystemClock
                                    .elapsedRealtime()

                            if (
                                newState ==
                                ScrollState.LOST
                            ) {
                                labelStore.clear()

                                forceOcrRequested =
                                    true

                                withContext(
                                    Dispatchers.Main
                                ) {
                                    overlay.clear()
                                }
                            } else {
                                if (
                                    motion.confidence >=
                                    MIN_APPLY_MOTION_CONFIDENCE
                                ) {
                                    labelStore
                                        .applyMotion(
                                            dy =
                                                motion.dy,
                                            confidence =
                                                motion.confidence,
                                            now =
                                                now
                                        )
                                } else {
                                    labelStore
                                        .markTrackingMiss()
                                }

                                labelStore
                                    .applyCorrections()

                                labelStore
                                    .purge(
                                        screenHeight =
                                            frame
                                                .sourceHeight,
                                        scrollState =
                                            newState,
                                        now =
                                            now
                                    )

                                val labels =
                                    labelStore
                                        .snapshot()

                                withContext(
                                    Dispatchers.Main
                                ) {
                                    if (
                                        labels
                                            .isEmpty()
                                    ) {
                                        overlay.clear()
                                    } else {
                                        overlay
                                            .showTrackedLabels(
                                                labels =
                                                    labels,
                                                sourceWidth =
                                                    frame
                                                        .sourceWidth,
                                                sourceHeight =
                                                    frame
                                                        .sourceHeight,
                                                settings =
                                                    activeSettings
                                            )
                                    }
                                }

                                if (
                                    oldState ==
                                    ScrollState.SCROLLING &&
                                    newState ==
                                    ScrollState.STOPPED
                                ) {
                                    forceOcrRequested =
                                        true
                                }
                            }

                            if (
                                now -
                                lastTrackingLogAt >=
                                TRACKING_LOG_INTERVAL_MS
                            ) {
                                debugLog.append(
                                    "tracking dy=${motion.dy} confidence=${motion.confidence} corr=${motion.correlation} bands=${motion.validBands} state=$newState labels=${labelStore.count()}"
                                )

                                lastTrackingLogAt =
                                    now
                            }
                        }

                        previousTrackingFrame =
                            frame
                    }

                    maybeStartOcr(
                        image =
                            image,
                        settings =
                            activeSettings,
                        now =
                            cycleStartedAt
                    )
                } catch (
                    error: Throwable
                ) {
                    debugLog.append(
                        "tracking error=${error::class.java.simpleName}: ${error.message}"
                    )

                    labelStore
                        .markTrackingMiss()
                } finally {
                    image.close()
                }

                val elapsed =
                    SystemClock
                        .elapsedRealtime() -
                    cycleStartedAt

                delay(
                    (
                        TRACKING_INTERVAL_MS -
                        elapsed
                    )
                        .coerceAtLeast(
                            MIN_TRACKING_DELAY_MS
                        )
                )
            }
        }
}

private fun maybeStartOcr(
    image: Image,
    settings:
        jp.nekoyuki.championsassist.settings.AssistSettings,
    now: Long
) {
    if (
        ocrJob?.isActive ==
        true
    ) {
        return
    }

    val interval =
        settings
            .scanIntervalMs
            .coerceIn(
                250L,
                2000L
            )

    if (
        !forceOcrRequested &&
        now -
        lastOcrStartedAt <
        interval
    ) {
        return
    }

    val fullBitmap =
        imageToBitmap(
            image
        )

    val sourceWidth =
        fullBitmap.width

    val sourceHeight =
        fullBitmap.height

    val crop =
        cropSkillArea(
            fullBitmap
        )

    if (
        crop.bitmap !==
        fullBitmap
    ) {
        fullBitmap.recycle()
    }

    forceOcrRequested =
        false

    lastOcrStartedAt =
        now

    ocrJob =
        scope.launch {
            runOcrCycle(
                crop =
                    crop,
                sourceWidth =
                    sourceWidth,
                sourceHeight =
                    sourceHeight,
                settings =
                    settings
            )
        }
}

private suspend fun runOcrCycle(
    crop: CroppedFrame,
    sourceWidth: Int,
    sourceHeight: Int,
    settings:
        jp.nekoyuki.championsassist.settings.AssistSettings
) {
    val startedAt =
        SystemClock
            .elapsedRealtime()

    try {
        val croppedResult =
            recognizer
                .recognize(
                    crop.bitmap
                )

        val result =
            restoreSourceCoordinates(
                result =
                    croppedResult,
                sourceWidth =
                    sourceWidth,
                sourceHeight =
                    sourceHeight,
                offsetX =
                    crop.offsetX,
                offsetY =
                    crop.offsetY
            )

        val matches =
            matcher.match(
                recognizedLines =
                    result.lines,
                skills =
                    currentSkills,
                minConfidence =
                    settings
                        .minConfidence
            )
                .filter {
                    settings
                        .shouldShowGrade(
                            it.grade
                        )
                }

        val now =
            SystemClock
                .elapsedRealtime()

        labelStore
            .reconcile(
                matches =
                    matches,
                now =
                    now,
                scrollState =
                    currentScrollState
            )

        labelStore
            .applyCorrections()

        labelStore
            .purge(
                screenHeight =
                    sourceHeight,
                scrollState =
                    currentScrollState,
                now =
                    now
            )

        val labels =
            labelStore
                .snapshot()

        withContext(
            Dispatchers.Main
        ) {
            if (
                labels.isEmpty()
            ) {
                overlay.clear()
            } else {
                overlay
                    .showTrackedLabels(
                        labels =
                            labels,
                        sourceWidth =
                            sourceWidth,
                        sourceHeight =
                            sourceHeight,
                        settings =
                            settings
                    )
            }
        }

        updateState(
            LiveAssistState(
                status =
                    LiveAssistStatus.RUNNING,
                message =
                    if (
                        labels.isEmpty()
                    ) {
                        "吸着追従中: 有効スキルは未検出"
                    } else {
                        "吸着追従中: ${labels.size}件を追跡"
                    },
                recognizedCount =
                    labels.size
            )
        )

        debugLog.append(
            "ocr ${SystemClock.elapsedRealtime() - startedAt}ms lines=${result.lines.size} matches=${matches.size} labels=${labels.size} state=$currentScrollState"
        )
    } catch (
        error: Throwable
    ) {
        debugLog.append(
            "ocr error=${error::class.java.simpleName}: ${error.message}"
        )
    } finally {
        if (
            !crop.bitmap
                .isRecycled
        ) {
            crop.bitmap.recycle()
        }
    }
}

private fun acquireLatestImageRaw():
    Image? {
    val reader =
        imageReader
            ?: return null

    return runCatching {
        reader
            .acquireLatestImage()
    }.getOrNull()
}

private suspend fun resetTracking(
    reason: String
) {
    previousTrackingFrame =
        null

    currentScrollState =
        ScrollState.STOPPED

    scrollDetector.reset()

    labelStore.clear()

    forceOcrRequested =
        true

    debugLog.append(
        "tracking reset: $reason"
    )

    withContext(
        Dispatchers.Main
    ) {
        overlay.clear()
    }
}

private data class CroppedFrame(
    val bitmap: Bitmap,
    val offsetX: Int,
    val offsetY: Int
)

private fun cropSkillArea(
    bitmap: Bitmap
): CroppedFrame {
    if (
        bitmap.height <=
        bitmap.width
    ) {
        return CroppedFrame(
            bitmap =
                bitmap,
            offsetX =
                0,
            offsetY =
                0
        )
    }

    val top =
        (
            bitmap.height *
            SKILL_CROP_TOP_PERCENT
        ) /
        100

    val bottom =
        (
            bitmap.height *
            SKILL_CROP_BOTTOM_PERCENT
        ) /
        100

    val safeBottom =
        bottom
            .coerceIn(
                top + 1,
                bitmap.height
            )

    val cropped =
        Bitmap.createBitmap(
            bitmap,
            0,
            top,
            bitmap.width,
            safeBottom -
                top
        )

    return CroppedFrame(
        bitmap =
            cropped,
        offsetX =
            0,
        offsetY =
            top
    )
}

private fun restoreSourceCoordinates(
    result: OcrResult,
    sourceWidth: Int,
    sourceHeight: Int,
    offsetX: Int,
    offsetY: Int
): OcrResult =
    result.copy(
        lines =
            result.lines
                .map {
                    line ->
                    line.copy(
                        left =
                            line.left
                                ?.plus(
                                    offsetX
                                ),
                        top =
                            line.top
                                ?.plus(
                                    offsetY
                                ),
                        right =
                            line.right
                                ?.plus(
                                    offsetX
                                ),
                        bottom =
                            line.bottom
                                ?.plus(
                                    offsetY
                                )
                    )
                },
        imageWidth =
            sourceWidth,
        imageHeight =
            sourceHeight
    )

    private fun drainPendingImages() {
        while (
            true
        ) {
            val image =
                runCatching {
                    imageReader
                        ?.acquireLatestImage()
                }.getOrNull()
                    ?: break

            image.close()
        }
    }

    private fun acquireLatestBitmap():
        Bitmap? {
        val reader =
            imageReader
                ?: return null

        val image =
            runCatching {
                reader
                    .acquireLatestImage()
            }.getOrNull()
                ?: return null

        return try {
            imageToBitmap(image)
        } finally {
            image.close()
        }
    }

    private fun imageToBitmap(
        image: Image
    ): Bitmap {
        val plane =
            image.planes[0]

        val buffer:
            ByteBuffer =
            plane.buffer

        buffer.rewind()

        val pixelStride =
            plane.pixelStride

        val rowStride =
            plane.rowStride

        val rowPadding =
            rowStride -
            pixelStride *
            image.width

        val paddedWidth =
            image.width +
            rowPadding /
            pixelStride

        val paddedBitmap =
            Bitmap.createBitmap(
                paddedWidth,
                image.height,
                Bitmap.Config.ARGB_8888
            )

        paddedBitmap
            .copyPixelsFromBuffer(
                buffer
            )

        if (
            paddedWidth ==
            image.width
        ) {
            return paddedBitmap
        }

        val cropped =
            Bitmap.createBitmap(
                paddedBitmap,
                0,
                0,
                image.width,
                image.height
            )

        paddedBitmap.recycle()

        return cropped
    }

    private fun updateCaptureMetrics() {
        val display =
            displayManager
                ?.getDisplay(
                    Display.DEFAULT_DISPLAY
                )

        val metrics =
            DisplayMetrics()

        @Suppress(
            "DEPRECATION"
        )
        display?.getRealMetrics(
            metrics
        )

        captureWidth =
            metrics
                .widthPixels
                .coerceAtLeast(1)

        captureHeight =
            metrics
                .heightPixels
                .coerceAtLeast(1)

        captureDensityDpi =
            metrics
                .densityDpi
                .coerceAtLeast(
                    DisplayMetrics
                        .DENSITY_DEFAULT
                )

        debugLog.append(
            "captureMetrics ${captureWidth}x${captureHeight} dpi=$captureDensityDpi"
        )
    }

    override fun onDisplayAdded(
        displayId: Int
    ) = Unit

    override fun onDisplayRemoved(
        displayId: Int
    ) = Unit

    override fun onDisplayChanged(
        displayId: Int
    ) {
        if (
            displayId !=
            Display.DEFAULT_DISPLAY
        ) {
            return
        }

        scope.launch {
            updateCaptureMetrics()

            withContext(
                Dispatchers.Main
            ) {
                createImageReaderAndDisplay()
            }
        }
    }

    private suspend fun stopEverything(
        message: String
    ) {
        debugLog.append(
            "stopEverything: $message"
        )
        trackingJob?.cancel()
        trackingJob = null

        ocrJob?.cancel()
        ocrJob = null

        labelStore.clear()

        previousTrackingFrame =
            null

        withContext(
            Dispatchers.Main
        ) {
            overlay.detach()
        }

        imageReader?.close()
        imageReader = null

        virtualDisplay?.release()
        virtualDisplay = null

        mediaProjection
            ?.unregisterCallback(
                projectionCallback
            )

        mediaProjection?.stop()
        mediaProjection = null

        updateState(
            LiveAssistState(
                status =
                    LiveAssistStatus.STOPPED,
                message = message
            )
        )

        stopForeground(
            STOP_FOREGROUND_REMOVE
        )

        stopSelf()
    }

    private fun createNotificationChannel() {
        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O
        ) {
            val manager =
                getSystemService(
                    Context.NOTIFICATION_SERVICE
                ) as NotificationManager

            manager.createNotificationChannel(
                NotificationChannel(
                    NOTIFICATION_CHANNEL_ID,
                    "Champions Assist",
                    NotificationManager
                        .IMPORTANCE_LOW
                )
            )
        }
    }

    private fun startProjectionForeground() {
        val openIntent =
            Intent(
                this,
                MainActivity::class.java
            )

        val openPendingIntent =
            PendingIntent.getActivity(
                this,
                10,
                openIntent,
                PendingIntent
                    .FLAG_UPDATE_CURRENT or
                PendingIntent
                    .FLAG_IMMUTABLE
            )

        val stopIntent =
            Intent(
                this,
                MediaProjectionAssistService::
                    class.java
            ).apply {
                action =
                    ACTION_STOP
            }

        val stopPendingIntent =
            PendingIntent.getService(
                this,
                11,
                stopIntent,
                PendingIntent
                    .FLAG_UPDATE_CURRENT or
                PendingIntent
                    .FLAG_IMMUTABLE
            )

        val notification =
            Notification
                .Builder(
                    this,
                    NOTIFICATION_CHANNEL_ID
                )
                .setSmallIcon(
                    android.R.drawable
                        .ic_menu_view
                )
                .setContentTitle(
                    "Champions Assist"
                )
                .setContentText(
                    "スキル画面を認識しています"
                )
                .setContentIntent(
                    openPendingIntent
                )
                .setOngoing(true)
                .addAction(
                    Notification.Action
                        .Builder(
                            Icon.createWithResource(
                                this,
                                android.R.drawable
                                    .ic_media_pause
                            ),
                            "停止",
                            stopPendingIntent
                        )
                        .build()
                )
                .build()

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.Q
        ) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo
                    .FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(
                NOTIFICATION_ID,
                notification
            )
        }
    }

    override fun onDestroy() {
        displayManager
            ?.unregisterDisplayListener(
                this
            )

        overlay.detach()

        trackingJob?.cancel()
        ocrJob?.cancel()

        labelStore.clear()

        imageReader?.close()

        virtualDisplay?.release()

        mediaProjection
            ?.unregisterCallback(
                projectionCallback
            )

        mediaProjection?.stop()

        recognizer.close()

        serviceJob.cancel()

        super.onDestroy()
    }

    private fun Intent.projectionIntentExtra():
        Intent? =
        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.TIRAMISU
        ) {
            getParcelableExtra(
                EXTRA_DATA,
                Intent::class.java
            )
        } else {
            @Suppress(
                "DEPRECATION"
            )
            getParcelableExtra(
                EXTRA_DATA
            )
        }

    private fun updateState(
        newState:
            LiveAssistState
    ) {
        _state.value =
            newState
    }

    companion object {
        const val ACTION_START =
            "jp.nekoyuki.championsassist.action.START"

        const val ACTION_STOP =
            "jp.nekoyuki.championsassist.action.STOP"

        const val ACTION_UPDATE_STYLE =
            "jp.nekoyuki.championsassist.action.UPDATE_STYLE"

        const val EXTRA_RESULT_CODE =
            "projection_result_code"

        const val EXTRA_DATA =
            "projection_data"

        const val EXTRA_STYLE =
            "running_style"

        private const val NOTIFICATION_CHANNEL_ID =
            "live_assist"

        private const val NOTIFICATION_ID =
            7001

        private const val TRACKING_INTERVAL_MS =
            45L

        private const val MIN_TRACKING_DELAY_MS =
            8L

        private const val TRACKING_IDLE_MS =
            12L

        private const val SETTINGS_RELOAD_MS =
            500L

        private const val TRACKING_LOG_INTERVAL_MS =
            2000L

        private const val MIN_APPLY_MOTION_CONFIDENCE =
            0.42f

        private const val SKILL_CROP_TOP_PERCENT =
            28

        private const val SKILL_CROP_BOTTOM_PERCENT =
            92

        private val _state =
            MutableStateFlow(
                LiveAssistState(
                    status =
                        LiveAssistStatus.STOPPED,
                    message =
                        "リアルタイムアシストは停止中です。"
                )
            )

        val state:
            StateFlow<LiveAssistState> =
            _state.asStateFlow()

        fun startIntent(
            context: Context,
            resultCode: Int,
            data: Intent,
            styleKey: String
        ): Intent =
            Intent(
                context,
                MediaProjectionAssistService::
                    class.java
            ).apply {
                action =
                    ACTION_START

                putExtra(
                    EXTRA_RESULT_CODE,
                    resultCode
                )

                putExtra(
                    EXTRA_DATA,
                    data
                )

                putExtra(
                    EXTRA_STYLE,
                    styleKey
                )
            }

        fun stopIntent(
            context: Context
        ): Intent =
            Intent(
                context,
                MediaProjectionAssistService::
                    class.java
            ).apply {
                action =
                    ACTION_STOP
            }

        fun updateStyleIntent(
            context: Context,
            styleKey: String
        ): Intent =
            Intent(
                context,
                MediaProjectionAssistService::
                    class.java
            ).apply {
                action =
                    ACTION_UPDATE_STYLE

                putExtra(
                    EXTRA_STYLE,
                    styleKey
                )
            }
    }
}
