# Champions Assist Starter v0.8

v0.7のリアルタイムOCR＋S/A/Bオーバーレイを、
**Xperia 1 Vなどの実機でデバッグしやすくするための調整機能**
まで統合した全部入り版です。

## v0.8の目的

ここから先は機能追加より実機確認が重要になります。

そのためv0.8では、
「ズレた」「拾わない」「拾いすぎる」「重い」
をアプリ内から調整できるようにしました。

## 新しい設定画面

### 表示評価
- S 表示 ON/OFF
- A 表示 ON/OFF
- B 表示 ON/OFF

例:
チャンミ本番ではSとAだけ表示、
という使い方ができます。

### 最低一致度
初期値:

82%

範囲:

75% ～ 98%

低くする:
- OCRミスを拾いやすい
- 誤一致も増えやすい

高くする:
- 誤一致を減らす
- OCRミス時に見逃しやすい

### スキャン間隔
初期値:

1400ms

範囲:

700ms ～ 3000ms

実機負荷とレスポンスを調整できます。

### オーバーレイ位置補正

X:
-250px ～ +250px

Y:
-250px ～ +250px

Xperia 1 Vの21:9画面や
ステータスバー差によるズレを
実機を見ながら補正できます。

### ラベル倍率
0.7x ～ 1.5x

S/A/B表示の大きさを変更できます。

### スキル文字枠
ON:
OCRしたスキル名を色枠でも囲む

OFF:
S/A/Bラベルのみ表示

## デバッグログ

内部ストレージ:

`filesDir/debug/live_assist.log`

以下を記録します。

- Service開始/停止
- 選択脚質
- 読み込んだ攻略スキル数
- キャプチャ解像度
- densityDpi
- OCR行数
- aliases一致件数
- 実際に表示した件数
- 一致度設定
- OCR/画面取得エラー

設定画面から:

- ログ更新
- クリップボードへコピー
- ログ消去

ができます。

実機で問題が出た場合、
このログをそのままChatGPTへ貼れば
原因を追いやすくなります。

## v0.7からの改善

リアルタイムServiceは毎スキャン時に
最新設定を読み直します。

そのため設定変更後に
アプリやServiceを再起動しなくても、

- S/A/B表示フィルタ
- 最低一致度
- スキャン間隔
- X/Y補正
- ラベル倍率
- 文字枠ON/OFF

が次のスキャンから反映されます。

スクリーンショットOCRにも
最低一致度とS/A/Bフィルタを反映します。

## 次の段階

ここで一度機能追加を止めて、
**Android Studioでビルド → Xperia 1 V実機デバッグ**
へ進みます。

最初に見るポイント:

1. Gradle Sync / コンパイルエラー
2. APKインストール
3. ホーム表示
4. latest.json更新
5. スクショOCR
6. MediaProjection開始
7. オーバーレイ権限
8. ウマ娘画面のOCR認識
9. S/A/B位置ズレ
10. 21:9画面での補正値
11. スクロール後の追従
12. 発熱・CPU負荷

v0.8の設定・ログ機能を使って、
実機で見つかった問題をv0.8.xとして潰していく想定です。


## v0.8.1: スマホだけでAPKを作るクラウドビルド

`.github/workflows/build-apk.yml` を追加しました。

GitHub Actionsが以下を自動実行します。

- JDK 17
- Android SDK 37
- Build Tools 36.0.0
- Gradle 9.6.0
- `:app:assembleDebug`
- APK artifact upload

生成物:

`ChampionsAssist-v0.8.1-debug.apk`

詳しいスマホ手順は:

`SMARTPHONE_BUILD_GUIDE.md`

を参照してください。


## v0.8.2 Build Fix

AGP 9.4向けにビルド設定を正式移行しました。

- `org.jetbrains.kotlin.android` を削除
- AGP 9組み込みKotlinを使用
- `android.kotlinOptions {}` を削除
- Java/Kotlin JVM targetは`compileOptions`のJava 17へ統一
- `compileSdk = 37`, `compileSdkMinor = 0`
- GitHub Actionsでは `platforms;android-37.0`
- Build Tools 36.0.0
- Gradle 9.6.0

## v0.8.3 Preflight

Remote Kotlin compileで判明した実エラーを修正:
- nullable MediaProjection
- inferred () -> Job callback

さらに静的preflightと、失敗時のコンパイラエラー抽出を追加。


## v0.8.4 Remote Data Connection

Public data repository connected:

`https://raw.githubusercontent.com/nekoyuki35p/champions-assist-data/main/latest.json`

The app now has a real remote `latest.json` endpoint configured.


## v0.8.5 Fast Tracking

高速スクロール時のリアルタイム評価ラベル追従を改善。

- target-period scan scheduler
- default 350ms scan
- persistent ML Kit recognizer
- skill-area OCR crop
- 45ms clean-capture delay
- stale-overlay auto clear
- v0.8.4 1400ms default setting migration


## v0.8.6 OCR + Scroll Tracking Hybrid

- ImageReaderのRGBA planeを直接サンプリング
- 左側3帯の縦特徴量からdyを推定
- 約45ms周期でTrackedSkillLabelを移動
- OCRは別周期でskillIdと正確な座標を再確認
- 小さいズレはLERP補正
- 大きいズレは即再ロック
- 画面外・連続OCR miss・LOSTで破棄
- スクロール停止時はOCRを即要求
