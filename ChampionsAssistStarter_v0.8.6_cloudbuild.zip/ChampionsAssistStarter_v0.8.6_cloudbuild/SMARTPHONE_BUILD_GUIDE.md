# Champions Assist v0.8.5 追従性改善版

## 改善内容

リアルタイムアシストの高速スクロール対策を追加しました。

- スキャン既定値: 1400ms → 350ms
- 旧1400ms設定は初回起動時に350msへ自動移行
- スキャン間隔を「OCR後の待ち時間」から「1周期の目標時間」へ変更
- ML Kit日本語OCRを毎回作り直さず再利用
- ウマ娘のスキル一覧領域だけをOCRして処理量を削減
- 自分自身のオーバーレイを隠す時間を140ms → 45msへ短縮
- 新しいOCR結果が来ない時は古いラベルを短時間で自動消去
- 設定画面のスキャン間隔を250～2000msへ拡張

## 推奨値

まず350msで使用してください。

追従がまだ遅ければ300msや250msも試せます。
短くするほどCPU負荷・発熱・バッテリー消費は増えます。

## ビルド

1. ZIPを開発用Private GitHubリポジトリへアップロード
2. `.github/workflows/build-apk.yml` をZIP内のv0.8.5版へ置換
3. Actions → Build Champions Assist APK → Run workflow
4. Artifact `ChampionsAssist-v0.8.5-debug-apk` を取得
