# latest.json 公開フォルダ

`latest.json` を HTTPS で直接取得できる場所へ置きます。

例:

- GitHub Pages
- Cloudflare Pages
- Firebase Hosting
- 自前の静的Webサーバー

公開後、Android側の

`app/src/main/assets/remote_config.json`

にURLを設定します。

```json
{
  "latestJsonUrl": "https://example.com/champions-assist/latest.json",
  "autoRefreshOnLaunch": true,
  "connectTimeoutMs": 10000,
  "readTimeoutMs": 15000,
  "maxPayloadBytes": 2097152
}
```

v0.5はHTTPSのみ許可します。

## 推奨レスポンス

可能なら以下を返してください。

- `Content-Type: application/json`
- `ETag`
- `Last-Modified`

アプリは `ETag` / `Last-Modified` を保存し、
次回以降 `If-None-Match` / `If-Modified-Since` を送ります。
サーバーが `304 Not Modified` を返せばJSON本体を再ダウンロードしません。
